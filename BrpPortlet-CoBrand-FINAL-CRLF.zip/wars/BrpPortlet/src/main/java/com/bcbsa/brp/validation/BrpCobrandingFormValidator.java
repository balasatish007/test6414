package com.bcbsa.brp.validation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.bcbsa.brp.constants.BRPConstants;
import com.bcbsa.brp.model.ServiceCategory;
import com.bcbsa.brp.model.util.BrandRequestVoMapper;
import com.bcbsa.brp.sanatize.InputSanitizer;
import com.bcbsa.brp.service.exception.ServiceException;
import com.bcbsa.brp.vo.BrandRequestVo;
import com.bcbsa.brp.vo.BusinessTypeVo;
import com.bcbsa.brp.vo.CobrandRenewalType;
import com.bcbsa.brp.vo.CobrandReviewTypeVo;
import com.bcbsa.brp.vo.GroupAccountTypeVo;
import com.bcbsa.brp.vo.PlanVo;
import com.bcbsa.brp.vo.ServiceCategoryVo;
import com.bcbsa.brp.vo.UsStateVo;

@Component
public class BrpCobrandingFormValidator implements Validator {

	@Autowired
	private BrandRequestVoMapper brandRequestVoMapper;

	private static String FIELD_ADDRESS1 = "address1";
	private static String FIELD_ADDRESS2 = "address2";
	private static String FIELD_CITY = "city";
	private static String FIELD_COBRAND_DESCRIPTION = "coBrandDescription";
	private static String FIELD_COBRAND_BUSINESS_TYPE = "businessType";
	private static String FIELD_COMPANY_WEBSITE = "companyWebSite";
	private static String FIELD_DANDB_NUMBER = "dandbNumber";
	private static String FIELD_GROUP_ACCOUNT_TYPE = "groupAccountType";
	//private static String FIELD_IS_TPA = "isTpa";
	private static String FIELD_IS_UNLICENSED_AFFILIATE = "isUnlicensed";
	private static String FIELD_LEGAL_NAME = "legalName";
	private static String FIELD_PHONE = "phone";
	private static String FIELD_SERVICE_CATEGORIES = "brandRqstServiceCategories";
	private static String BCBSA_SERVICE_CATEGORIES= "coBrandBcbsaSupportList";
	private static String FIELD_SERVICE_REQUEST = "cobrandReviewType";
	private static String FIELD_RENEWAL_REQUEST ="cobrandRenewalType";
	private static String FIELD_SERVICE_REQUEST_RENWAL_DESC = "cbStrategicRenewRational";
	private static String FIELD_SERVICE_REQUEST_RENWAL_DESC_FACT = "cbStrategicDecisionFact";
	private static String FIELD_STATE = "state";
	private static String FIELD_STATE_INCORPORATED = "stateOfIncorporation";
	private static String FIELD_TRADE_NAME = "tradeNames";
	private static String FIELD_ZIPCODE = "zipCode";
	private static String FIELD_REQTD_RESP_DATE = "requestedResponseDate";

	// Max length has been set to match the table field length.
	private static int MAX_LENGTH_TEXT_FIELD = 99;

	private static String MESSAGE_KEY_LEGAL_NAME_REQUIRED = "field.legalname.required";
	private static String MESSAGE_KEY_LEGAL_NAME_INVALID = "field.legalname.invalid";
	private static String MESSAGE_KEY_LEGAL_NAME_LENGTH_EXCEEDED = "field.legalname.length.exceeded";

	//private static String MESSAGE_KEY_TRADE_NAME_REQUIRED = "field.tradename.required";
	private static String MESSAGE_KEY_TRADE_NAME_INVALID = "field.tradename.invalid";
	private static String MESSAGE_KEY_TRADE_NAME_LENGTH_EXCEEDED = "field.tradename.length.exceeded";

	private static String MESSAGE_KEY_SERVICE_REQUEST_REQUIRED = "field.servicerequest.required";
	private static String MESSAGE_KEY_RENEWAL_REQUEST_REQUIRED = "field.renewalrequest.required";
	private static String MESSAGE_KEY_SERVICE_CATEGORY_REQUIRED = "field.servicecategory.required";
	private static String MESSAGE_KEY_OTHER_SERVICE_CATEGORY_REQUIRED = "field.other.servicecategory.required";

	private static String MESSAGE_KEY_STATE_OF_INCORPORATION_REQUIRED = "field.stateofincorporation.required";

	private static String MESSAGE_KEY_ADDRESS1_REQUIRED = "field.address1.required";
	private static String MESSAGE_KEY_ADDRESS1_INVALID = "field.address1.invalid";
	private static String MESSAGE_KEY_ADDRESS1_LENGTH_EXCEEDED = "field.address1.length.exceeded";

	private static String MESSAGE_KEY_ADDRESS2_INVALID = "field.address2.invalid";
	private static String MESSAGE_KEY_ADDRESS2_LENGTH_EXCEEDED = "field.address2.length.exceeded";

	private static String MESSAGE_KEY_CITY_REQUIRED = "field.city.required";
	private static String MESSAGE_KEY_CITY_INVALID = "field.city.invalid";
	private static String MESSAGE_KEY_CITY_LENGTH_EXCEEDED = "field.city.length.exceeded";

	private static String MESSAGE_KEY_STATE_REQUIRED = "field.state.required";

	private static String MESSAGE_KEY_ZIPCODE_REQUIRED = "field.zipcode.required";
	private static String MESSAGE_KEY_ZIPCODE_INVALID = "field.zipcode.invalid";
	private static String MESSAGE_KEY_ZIPCODE_LENGTH_EXCEEDED = "field.city.zipcode.exceeded";

	private static String MESSAGE_KEY_PHONE_REQUIRED = "field.phone.required";
	private static String MESSAGE_KEY_PHONE_INVALID = "field.phone.invalid";

	private static String MESSAGE_KEY_DANDB_NUMBER_INVALID = "field.dandbnumber.invalid";
	private static String MESSAGE_KEY_DANDB_NUMBER_LENGTH_EXCEEDED = "field.dandbnumber.length.exceeded";

	private static String MESSAGE_KEY_COMPANY_WEBSITE_REQUIRED = "field.companywebsite.required";
	private static String MESSAGE_KEY_COMPANY_WEBSITE_INVALID = "field.companywebsite.invalid";
	private static String MESSAGE_KEY_COMPANY_WEBSITE_LENGTH_EXCEEDED = "field.companywebsite.length.exceeded";
	private static String MESSAGE_KEY_IS_UNLICENSED_AFFILIATE_REQUIRED = "field.unlicensedaffiliate.required";
	private static String MESSAGE_KEY_IS_PLAN_REQUIRED = "field.plan.required";
	private static String MESSAGE_KEY_BUSINESS_TYPE_REQUIRED = "field.businesstype.required";
	private static String MESSAGE_KEY_GROUP_ACCOUNT_TYPE_REQUIRED = "field.groupaccounttype.required";
	//private static String MESSAGE_KEY_IS_TPA_REQUIRED = "field.istpa.required";
	private static String MESSAGE_KEY_COBRANDING_DESCRIPTION_REQUIRED = "field.cobrandingdescription.required";
	//private static String MESSAGE_KEY_COBRANDING_DESCRIPTION_LENGTH_EXCEEDED = "field.cobrandingdescription.length.exceeded";
	private static String MESSAGE_KEY_REQTD_RESP_DATE_FORMAT = "field.requested.response.date.format";

	private static String MESSAGE_KEY_SERVICE_REQUEST_RENWAL_DESC_REQUIRED = "field.servicerequest.renwalDesc.required";
	private static String MESSAGE_KEY_SERVICE_REQUEST_RENWAL_DESC_FACT_REQUIRED = "field.servicerequest.renwalDesc.fact.required";
	private static String MESSAGE_KEY_SERVICE_REQUEST_BCBSA_SERVICE_REQUIRED = "field.bcbsa.servicerequest.required";

	// TODO: These regular expressions may have to be tested more and fine tuned
	// accordingly
	// private static String REGEX_ALPHA_WITH_SPACE = "[a-zA-Z ]+$";
	private static String REGEX_ALPHA_NUMERIC_WITH_SPACE = "^[a-zA-Z0-9 ]*$";
	private static String REGEX_ALPHA_NUMERIC_WITH_SPACE_COMMA_SQ = "^[a-zA-Z0-9 ,'.\\-&]*$";
	//private static String REGEX_NUMERIC = "^(0|[1-9][0-9]*)$";
	private static String REGEX_DNB_NUM = "^[0-9-]*$";
	private static String REGEX_PHONE = "^.{7,20}$"; // "^\\+?[1-9]{1}[0-9]{6,14}$"; // "^\\(?([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$";
	private static String REGEX_URL = "^[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]"; //^(http:\\/\\/|https:\\/\\/)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?$";
	
	//Co-Branding Partner Form 17-question enhancement constants start

	// Q1-Q9 Brand Questions (always required for new submissions)
	private static String FIELD_Q1_LEGAL_NAME = "cbQ1LegalNameCnfrmd";
	private static String FIELD_Q2_DEBIT_CARD = "cbQ2DebitCardInd";
	private static String FIELD_Q2_LICENSE_DT = "cbQ2LicenseAgmtDt";
	private static String FIELD_Q3_CLIENT_LIST = "cbQ3ClientListInd";
	private static String FIELD_Q3_EXCEPTION_ACK = "cbQ3ExceptionAckInd";
	private static String FIELD_Q4_BRAND_MISUSE = "cbQ4BrandMisuseInd";
	private static String FIELD_Q4_LINKS = "cbQ4MisuseLinksTxt";
	private static String FIELD_Q4_CONTACT = "cbQ4MisuseContactTxt";
	private static String FIELD_Q4_ACK = "cbQ4MisuseAckInd";
	private static String FIELD_Q5_INFRNG = "cbQ5NameLogoInfrngInd";
	private static String FIELD_Q5_LINKS = "cbQ5InfrngLinksTxt";
	private static String FIELD_Q5_CONTACT = "cbQ5InfrngContactTxt";
	private static String FIELD_Q5_ACK = "cbQ5InfrngAckInd";
	private static String FIELD_Q6_FINL_STABLE = "cbQ6FinlStableInd";
	private static String FIELD_Q7_FELONY = "cbQ7FelonyInd";
	private static String FIELD_Q8_NOT_ON_LIST = "cbQ8NotOnListInd";
	private static String FIELD_Q9_REPUTATION = "cbQ9ReputationInd";

	// Q10-Q17 IPP Questions (required only when serviceCatQuestionsFlag = Y)
	private static String FIELD_Q10_IPP_EXEC = "cbQ10InterPlanExecTxt";
	private static String FIELD_Q11_BLUE_BENEFITS = "serviceCategoryBlueBenefit";
	private static String FIELD_Q11_OTHER_TXT = "cbQ11OtherTxt";
	private static String FIELD_Q12_TELEHEALTH = "cbQ12TelehealthSvcInd";
	private static String FIELD_Q13_VIRTUAL_ONLY = "cbQ13VirtualOnlyInd";
	private static String FIELD_Q14_NATL_MEMBERS = "serviceCategoryNationalAccountMember";
	private static String FIELD_Q15_SERVICES_ENTAIL = "serviceCategoryServiceEntail";
	private static String FIELD_Q16_PROVIDER_OUTREACH = "cbQ16ProviderOutreachInd";
	private static String FIELD_Q17_PROVIDER_OUTREACH_TXT = "cbQ17ProviderOutreachTxt";

	// Message keys
	private static String MSG_Q1_REQUIRED = "field.cbQ1.required";
	private static String MSG_Q2_REQUIRED = "field.cbQ2.required";
	private static String MSG_Q2_DATE_REQUIRED = "field.cbQ2Date.required";
	private static String MSG_Q3_REQUIRED = "field.cbQ3.required";
	private static String MSG_Q3_ACK_REQUIRED = "field.cbQ3Ack.required";
	private static String MSG_Q4_REQUIRED = "field.cbQ4.required";
	private static String MSG_Q4_LINKS_REQUIRED = "field.cbQ4Links.required";
	private static String MSG_Q4_CONTACT_REQUIRED = "field.cbQ4Contact.required";
	private static String MSG_Q4_ACK_REQUIRED = "field.cbQ4Ack.required";
	private static String MSG_Q5_REQUIRED = "field.cbQ5.required";
	private static String MSG_Q5_LINKS_REQUIRED = "field.cbQ5Links.required";
	private static String MSG_Q5_CONTACT_REQUIRED = "field.cbQ5Contact.required";
	private static String MSG_Q5_ACK_REQUIRED = "field.cbQ5Ack.required";
	private static String MSG_Q6_REQUIRED = "field.cbQ6.required";
	private static String MSG_Q7_REQUIRED = "field.cbQ7.required";
	private static String MSG_Q8_REQUIRED = "field.cbQ8.required";
	private static String MSG_Q9_REQUIRED = "field.cbQ9.required";
	private static String MSG_Q10_REQUIRED = "field.cbQ10.required";
	private static String MSG_Q11_REQUIRED = "field.cbQ11.required";
	private static String MSG_Q11_OTHER_REQUIRED = "field.cbQ11Other.required";
	private static String MSG_Q12_REQUIRED = "field.cbQ12.required";
	private static String MSG_Q13_REQUIRED = "field.cbQ13.required";
	private static String MSG_Q14_REQUIRED = "field.cbQ14.required";
	private static String MSG_Q15_REQUIRED = "field.cbQ15.required";
	private static String MSG_Q16_REQUIRED = "field.cbQ16.required";
	private static String MSG_Q17_REQUIRED = "field.cbQ17.required";

	// Constants for Q11 radio values
	private static final String Q11_CARVEOUT = "CARVEOUT";
	private static final String Q11_CLAIM = "CLAIM";
	private static final String Q11_OTHER = "OTHER";

	//Co-Branding Partner Form 17-question enhancement constants end
	
	@Override
	public boolean supports(Class<?> clazz) {
		return BrandRequestVo.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// LDAP INJECTION. SANITIZE INPUT - ANTI-SAMY & HTMLUTIL.
	    // + * ? [ ^ ] $ ( ) { } = ! < > | : \ &
		
		BrandRequestVo brandRequestVo = (BrandRequestVo) target;
		
		try {
		// Validating Legal Name
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_LEGAL_NAME, MESSAGE_KEY_LEGAL_NAME_REQUIRED);
		String legalName = brandRequestVo.getLegalName();
		System.out.println("Legal Name Value: " + legalName);
		if (StringUtils.isNotEmpty(legalName)) {
			//System.out.println("InputSanitizer.sanitize(legalName): "+santizeInput(legalName));
			legalName = santizeInput(legalName);
			if (!isMatchingPattern(legalName, REGEX_ALPHA_NUMERIC_WITH_SPACE_COMMA_SQ)) {
				errors.rejectValue(FIELD_LEGAL_NAME, MESSAGE_KEY_LEGAL_NAME_INVALID);
			} else {
				if (legalName.length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_LEGAL_NAME, MESSAGE_KEY_LEGAL_NAME_LENGTH_EXCEEDED);
				}
			}
		}

		// Validating Trade Name(s)
		String[] tradeNames = brandRequestVo.getTradeNames();
		if (tradeNames == null || (tradeNames != null && tradeNames.length == 0)) {
			//Commented below validation line as per the request from Nick on 12/19/2016
			//errors.rejectValue(FIELD_TRADE_NAME, MESSAGE_KEY_TRADE_NAME_REQUIRED);
		} else {
			for (String str : tradeNames) {
				if (StringUtils.isNotEmpty(str)) {
					System.out.println("Each Trade Name: " + str);
					//System.out.println("InputSanitizer.sanitize(tradename): "+santizeInput(str));
					str = santizeInput(str);
					if (!isMatchingPattern(str, REGEX_ALPHA_NUMERIC_WITH_SPACE_COMMA_SQ)) {
						errors.rejectValue(FIELD_TRADE_NAME, MESSAGE_KEY_TRADE_NAME_INVALID);
					} else {
						if (StringUtils.trimToEmpty(str).length() > MAX_LENGTH_TEXT_FIELD) {
							errors.rejectValue(FIELD_TRADE_NAME, MESSAGE_KEY_TRADE_NAME_LENGTH_EXCEEDED);
						}
					}
				}
			}
		}

		// Validating Service Request (aka CobrandReviewType)
		CobrandReviewTypeVo cobrandReviewType = brandRequestVo.getCobrandReviewType();
		Long serviceRequest =0L;
		if(cobrandReviewType!=null){			
			serviceRequest = cobrandReviewType.getCobrandRevwTypUid();
		}
		if (serviceRequest==null ||serviceRequest == 0L) {
			errors.rejectValue(FIELD_SERVICE_REQUEST, MESSAGE_KEY_SERVICE_REQUEST_REQUIRED);
		}
		
		Map<String,String> cobrandRenwalTypes=null;
		String cobrandRenewTypeName=null;
		CobrandRenewalType cobrandRenewalType = brandRequestVo.getCobrandRenewalType();
		try{
			cobrandRenwalTypes= brandRequestVoMapper.getCobrandRenewalTypesMap();
			if(cobrandRenewalType!=null && cobrandRenewalType.getCobrandRenwTypUid()!=null)
				cobrandRenewTypeName=cobrandRenwalTypes.get(""+ cobrandRenewalType.getCobrandRenwTypUid());
			if(cobrandRenewTypeName.equalsIgnoreCase("Strategic")){
				cobrandRenewTypeName=cobrandRenewTypeName+"- Renewal";
			}
		}catch(Exception e){

		}
		
		
		
		/*if (cobrandRenewalType==null ||cobrandRenewalType.getCobrandRenwTypUid()!=null) {
			errors.rejectValue(FIELD_RENEWAL_REQUEST, MESSAGE_KEY_RENEWAL_REQUEST_REQUIRED);
		}*/


		if (cobrandRenewalType!=null && "Strategic- Renewal".equals(cobrandRenewTypeName)) {
			String cbStrategicRenewRational = brandRequestVo.getCbStrategicRenewRational();
			if(cbStrategicRenewRational==null || cbStrategicRenewRational.trim().equals("")){
				cobrandRenewalType.setSelected(true);
				errors.rejectValue(FIELD_SERVICE_REQUEST_RENWAL_DESC, MESSAGE_KEY_SERVICE_REQUEST_RENWAL_DESC_REQUIRED);
			}
		}
		Map<String,String> cobrandReviewTypes=null;	
		String cobrandReviewTypeName=null;

		try{
			cobrandReviewTypes= brandRequestVoMapper.getActiveCobrandReviewTypesMap();
			if(cobrandReviewType!=null && cobrandReviewType.getCobrandRevwTypUid()!=null)
				cobrandReviewTypeName=cobrandReviewTypes.get(""+ cobrandReviewType.getCobrandRevwTypUid().toString());
		}catch(Exception e){

		}
		if (cobrandReviewType!=null && "Strategic".equals(cobrandReviewTypeName)) {
			String cbStrategicDecisionFact = brandRequestVo.getCbStrategicDecisionFact();
			if(cbStrategicDecisionFact==null || cbStrategicDecisionFact.trim().equals("")){
				errors.rejectValue(FIELD_SERVICE_REQUEST_RENWAL_DESC_FACT, MESSAGE_KEY_SERVICE_REQUEST_RENWAL_DESC_FACT_REQUIRED);
			}
		}

		/*if (cobrandReviewType!=null && !"Select".equals(cobrandReviewTypeName) || !"New Service Category Select".equals(cobrandReviewTypeName)) {
			String cbStrategicDecisionFact = brandRequestVo.getCbStrategicDecisionFact();
			if(cbStrategicDecisionFact==null || cbStrategicDecisionFact.trim().equals("")){
				errors.rejectValue(FIELD_SERVICE_REQUEST_RENWAL_DESC_FACT, MESSAGE_KEY_SERVICE_REQUEST_RENWAL_DESC_FACT_REQUIRED);
			}
		}*/
  
	if (cobrandReviewType!=null && "Select".equals(cobrandReviewTypeName)){
		String[] coBrandBcbsaSupportList=brandRequestVo.getCoBrandBcbsaSupportList();
		if (coBrandBcbsaSupportList == null || coBrandBcbsaSupportList.length==0) {
			errors.rejectValue(BCBSA_SERVICE_CATEGORIES, MESSAGE_KEY_SERVICE_REQUEST_BCBSA_SERVICE_REQUIRED);
		}
	}

		// Validating Service Categories
		List<ServiceCategoryVo> serviceCategories = brandRequestVo.getBrandRqstServiceCategories();
		if (serviceCategories == null || serviceCategories.isEmpty()) {
			errors.rejectValue(FIELD_SERVICE_CATEGORIES, MESSAGE_KEY_SERVICE_CATEGORY_REQUIRED);
		} else {
			boolean isSelectedSomething = false;
			for (ServiceCategoryVo scvo : serviceCategories) {
				if (scvo.getSrvcCtgyUid() != null && scvo.getSrvcCtgyUid() != "0") {
					isSelectedSomething = true;
					break;
				}
			}

			if (!isSelectedSomething) {
				errors.rejectValue(FIELD_SERVICE_CATEGORIES, MESSAGE_KEY_SERVICE_CATEGORY_REQUIRED);
			} else {
				if (isOtherServiceCategoryChecked(brandRequestVo.getBrandRqstServiceCategoriesCsv())) {
					if (StringUtils.isEmpty(brandRequestVo.getOthSrvcCtgyNm())) {
						errors.rejectValue(FIELD_SERVICE_CATEGORIES, MESSAGE_KEY_OTHER_SERVICE_CATEGORY_REQUIRED);
					}
					else {
                        santizeInput(brandRequestVo.getOthSrvcCtgyNm());
                 }

				}
			}
		}
		
		//Co-Branding Partner Form 17-question enhancement validation start

		// --- Q1-Q9 Brand Questions: always required ---
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q1_LEGAL_NAME, MSG_Q1_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q2_DEBIT_CARD, MSG_Q2_REQUIRED);

		// Q2: if Yes, date is required
		String q2 = brandRequestVo.getCbQ2DebitCardInd();
		if ("Y".equalsIgnoreCase(q2)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q2_LICENSE_DT, MSG_Q2_DATE_REQUIRED);
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q3_CLIENT_LIST, MSG_Q3_REQUIRED);
		// Q3: if Yes, acknowledgement checkbox required
		String q3 = brandRequestVo.getCbQ3ClientListInd();
		if ("Y".equalsIgnoreCase(q3)) {
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ3ExceptionAckInd())) {
				errors.rejectValue(FIELD_Q3_EXCEPTION_ACK, MSG_Q3_ACK_REQUIRED);
			}
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_BRAND_MISUSE, MSG_Q4_REQUIRED);
		// Q4: if Yes, links + contact + ack all required
		String q4 = brandRequestVo.getCbQ4BrandMisuseInd();
		if ("Y".equalsIgnoreCase(q4)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_LINKS, MSG_Q4_LINKS_REQUIRED);
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q4_CONTACT, MSG_Q4_CONTACT_REQUIRED);
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ4MisuseAckInd())) {
				errors.rejectValue(FIELD_Q4_ACK, MSG_Q4_ACK_REQUIRED);
			}
			santizeInput(brandRequestVo.getCbQ4MisuseLinksTxt());
			santizeInput(brandRequestVo.getCbQ4MisuseContactTxt());
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_INFRNG, MSG_Q5_REQUIRED);
		// Q5: if Yes, links + contact + ack all required
		String q5 = brandRequestVo.getCbQ5NameLogoInfrngInd();
		if ("Y".equalsIgnoreCase(q5)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_LINKS, MSG_Q5_LINKS_REQUIRED);
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q5_CONTACT, MSG_Q5_CONTACT_REQUIRED);
			if (!"Y".equalsIgnoreCase(brandRequestVo.getCbQ5InfrngAckInd())) {
				errors.rejectValue(FIELD_Q5_ACK, MSG_Q5_ACK_REQUIRED);
			}
			santizeInput(brandRequestVo.getCbQ5InfrngLinksTxt());
			santizeInput(brandRequestVo.getCbQ5InfrngContactTxt());
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q6_FINL_STABLE, MSG_Q6_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q7_FELONY, MSG_Q7_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q8_NOT_ON_LIST, MSG_Q8_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q9_REPUTATION, MSG_Q9_REQUIRED);

		// --- Q10-Q17 IPP Questions: required only when serviceCatQuestionsFlag = Y ---
		String serviceCatQuestionsFlag = brandRequestVo.getServiceCatQuestionsFlag();
		if (serviceCatQuestionsFlag != null && serviceCatQuestionsFlag.equalsIgnoreCase("Y")) {

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q10_IPP_EXEC, MSG_Q10_REQUIRED);
			santizeInput(brandRequestVo.getCbQ10InterPlanExecTxt());

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q11_BLUE_BENEFITS, MSG_Q11_REQUIRED);
			String q11 = brandRequestVo.getServiceCategoryBlueBenefit();
			if (StringUtils.isNotEmpty(q11)) {
				q11 = santizeInput(q11);
			}

			if (Q11_OTHER.equalsIgnoreCase(q11)) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q11_OTHER_TXT, MSG_Q11_OTHER_REQUIRED);
				santizeInput(brandRequestVo.getCbQ11OtherTxt());
				validateQ14Q15Q16Q17(brandRequestVo, errors);
			} else if (Q11_CLAIM.equalsIgnoreCase(q11)) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q12_TELEHEALTH, MSG_Q12_REQUIRED);
				String q12 = brandRequestVo.getCbQ12TelehealthSvcInd();
				if ("Y".equalsIgnoreCase(q12)) {
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q13_VIRTUAL_ONLY, MSG_Q13_REQUIRED);
					String q13 = brandRequestVo.getCbQ13VirtualOnlyInd();
					if ("N".equalsIgnoreCase(q13)) {
						validateQ14Q15Q16Q17(brandRequestVo, errors);
					}
				} else if ("N".equalsIgnoreCase(q12)) {
					validateQ14Q15Q16Q17(brandRequestVo, errors);
				}
			}
			// Q11 = CARVEOUT -> STOP, no further questions
		}
		//Co-Branding Partner Form 17-question enhancement validation end
		// Validating State Of Incorporation
		UsStateVo stateOfIncorporation = brandRequestVo.getStateOfIncorporation();
		if (stateOfIncorporation == null) {
			errors.rejectValue(FIELD_STATE_INCORPORATED, MESSAGE_KEY_STATE_OF_INCORPORATION_REQUIRED);
		} else {
			String stateCode = stateOfIncorporation.getUsStateCd();
			if (StringUtils.isNotEmpty(stateCode) && stateCode.equals("0")) {
				errors.rejectValue(FIELD_STATE_INCORPORATED, MESSAGE_KEY_STATE_OF_INCORPORATION_REQUIRED);
			}
		}

		// TODO: More robust Address validation strategy needs to be added. This
		// will validate international address also. This include address1,
		// address2, city, state, zipcode and country
		// Validating Address1
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_ADDRESS1, MESSAGE_KEY_ADDRESS1_REQUIRED);

		String address1 = brandRequestVo.getAddress1();
		if (StringUtils.isNotEmpty(address1)) {
			//System.out.println("InputSanitizer.sanitize(address1): "+santizeInput(address1));
			address1 = santizeInput(address1);
			if (!isMatchingPattern(address1, REGEX_ALPHA_NUMERIC_WITH_SPACE_COMMA_SQ)) {
				errors.rejectValue(FIELD_ADDRESS1, MESSAGE_KEY_ADDRESS1_INVALID);
			} else {
				if (StringUtils.trim(address1).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_ADDRESS1, MESSAGE_KEY_ADDRESS1_LENGTH_EXCEEDED);
				}
			}

		}

		// Validating Address2
		String address2 = brandRequestVo.getAddress2();
		if (StringUtils.isNotEmpty(address2)) {
			//System.out.println("InputSanitizer.sanitize(address2): "+santizeInput(address2));
			address2 = santizeInput(address2);
			if (!isMatchingPattern(address2, REGEX_ALPHA_NUMERIC_WITH_SPACE_COMMA_SQ)) {
				errors.rejectValue(FIELD_ADDRESS2, MESSAGE_KEY_ADDRESS2_INVALID);
			} else {
				if (StringUtils.trim(address2).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_ADDRESS2, MESSAGE_KEY_ADDRESS2_LENGTH_EXCEEDED);
				}
			}

		}

		// Validating City
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_CITY, MESSAGE_KEY_CITY_REQUIRED);
		String city = brandRequestVo.getCity();
		if (StringUtils.isNotEmpty(city)) {
			//System.out.println("InputSanitizer.sanitize(city): "+santizeInput(city));
			city = santizeInput(city);
			if (!isMatchingPattern(city, REGEX_ALPHA_NUMERIC_WITH_SPACE)) {
				errors.rejectValue(FIELD_CITY, MESSAGE_KEY_CITY_INVALID);
			} else {
				if (StringUtils.trim(city).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_CITY, MESSAGE_KEY_CITY_LENGTH_EXCEEDED);
				}
			}
		}

		// Validating State
		UsStateVo state = brandRequestVo.getState();
		if (state == null) {
			errors.rejectValue(FIELD_STATE, MESSAGE_KEY_STATE_REQUIRED);
		} else {
			String stateCode = state.getUsStateCd();
			if (StringUtils.isNotEmpty(stateCode) && stateCode.equals("0")) {
				errors.rejectValue(FIELD_STATE, MESSAGE_KEY_STATE_REQUIRED);
			}
		}

		// Validating Zip
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_ZIPCODE, MESSAGE_KEY_ZIPCODE_REQUIRED);
		String zip = brandRequestVo.getZipCode();
		if (StringUtils.isNotEmpty(zip)) {
			//System.out.println("InputSanitizer.sanitize(zip): "+santizeInput(zip));
			zip = santizeInput(zip);
			if (!isMatchingPattern(zip, REGEX_ALPHA_NUMERIC_WITH_SPACE)) {
				errors.rejectValue(FIELD_ZIPCODE, MESSAGE_KEY_ZIPCODE_INVALID);
			} else {
				if (StringUtils.trim(zip).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_ZIPCODE, MESSAGE_KEY_ZIPCODE_LENGTH_EXCEEDED);
				}
			}
		}

		// Validating Phone
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_PHONE, MESSAGE_KEY_PHONE_REQUIRED);
		String phone = brandRequestVo.getPhone();
		if (StringUtils.isNotEmpty(phone)) {
			//System.out.println("InputSanitizer.sanitize(phone): "+santizeInput(phone));
			phone = santizeInput(phone);
			if (!isMatchingPattern(phone, REGEX_PHONE)) {
				errors.rejectValue(FIELD_PHONE, MESSAGE_KEY_PHONE_INVALID);
			}

		}

		// Validating D & B Number
		String dandbNumber = brandRequestVo.getDandbNumber();
		if (StringUtils.isNotEmpty(dandbNumber)) {
			//System.out.println("InputSanitizer.sanitize(dandbNumber): "+santizeInput(dandbNumber));
			dandbNumber = santizeInput(dandbNumber);
			if (!isMatchingPattern(dandbNumber, REGEX_DNB_NUM)) {
				errors.rejectValue(FIELD_DANDB_NUMBER, MESSAGE_KEY_DANDB_NUMBER_INVALID);
			} else {
				if (StringUtils.trim(dandbNumber).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_DANDB_NUMBER, MESSAGE_KEY_DANDB_NUMBER_LENGTH_EXCEEDED);
				}
			}
		}

		// Validating Company Website
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_COMPANY_WEBSITE, MESSAGE_KEY_COMPANY_WEBSITE_REQUIRED);
		String companyWebsite = brandRequestVo.getCompanyWebSite();
		if (StringUtils.isNotEmpty(companyWebsite)) {
			//System.out.println("InputSanitizer.sanitize(companyWebsite): "+santizeInput(companyWebsite));
			companyWebsite = santizeInput(companyWebsite);
			if (!isMatchingPattern(companyWebsite, REGEX_URL)) {
				errors.rejectValue(FIELD_COMPANY_WEBSITE, MESSAGE_KEY_COMPANY_WEBSITE_INVALID);
			} else {
				// On table, we have just 99 characters for this URL field
				if (StringUtils.trim(companyWebsite).length() > MAX_LENGTH_TEXT_FIELD) {
					errors.rejectValue(FIELD_COMPANY_WEBSITE, MESSAGE_KEY_COMPANY_WEBSITE_LENGTH_EXCEEDED);
				}
			}
		}

		// Validating Is Unlicensed Affiliate
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_IS_UNLICENSED_AFFILIATE,
				MESSAGE_KEY_IS_UNLICENSED_AFFILIATE_REQUIRED);
		String isUnlicensed = brandRequestVo.getIsUnlicensed();
		if ("Yes".equals(isUnlicensed)) {
			PlanVo plan = brandRequestVo.getPlan();
			if (plan != null && ("0").equals(plan.getPlanCd())) {
				errors.rejectValue(FIELD_IS_UNLICENSED_AFFILIATE, MESSAGE_KEY_IS_PLAN_REQUIRED);
			}
		}

		BusinessTypeVo businessType = brandRequestVo.getBusinessType();
		if (businessType == null) {
			errors.rejectValue(FIELD_COBRAND_BUSINESS_TYPE, MESSAGE_KEY_BUSINESS_TYPE_REQUIRED);
		} else {
			String businessTypeCode = businessType.getBusTypCd();
			if (StringUtils.isNotEmpty(businessTypeCode)) {
				//System.out.println("InputSanitizer.sanitize(businessTypeCode): "+santizeInput(businessTypeCode));
				businessTypeCode = santizeInput(businessTypeCode);
			}
			if (StringUtils.isNotEmpty(businessTypeCode) && businessTypeCode.equals("0")) {
				errors.rejectValue(FIELD_COBRAND_BUSINESS_TYPE, MESSAGE_KEY_BUSINESS_TYPE_REQUIRED);
			}
		}

		// Group Account Type validation removed - field no longer collected by form.

		/*    // Validating Is Company a Third Party Administrator (TPA)
    if (StringUtils.isEmpty(brandRequestVo.getIsTpa())) {
      errors.rejectValue(FIELD_IS_TPA, MESSAGE_KEY_IS_TPA_REQUIRED);
    }*/

		// Validating Co-Branding Description
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_COBRAND_DESCRIPTION,
				MESSAGE_KEY_COBRANDING_DESCRIPTION_REQUIRED);
		String coBrandDescription = brandRequestVo.getCoBrandDescription();
		if (StringUtils.isNotEmpty(coBrandDescription)) {
			//System.out.println("InputSanitizer.sanitize(coBrandDescription): "+santizeInput(coBrandDescription));
			coBrandDescription = santizeInput(coBrandDescription);
		}
		/* String coBrandDescription = brandRequestVo.getCoBrandDescription();
    if (StringUtils.isNotEmpty(coBrandDescription)) {
      if (StringUtils.trim(coBrandDescription).length() > MAX_LENGTH_TEXT_AREA) {
        errors.rejectValue(FIELD_COBRAND_DESCRIPTION, MESSAGE_KEY_COBRANDING_DESCRIPTION_LENGTH_EXCEEDED);
      }
    }*/


		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		if(null != brandRequestVo.getRequestedResponseDate())
			try {
				df.parse(brandRequestVo.getRequestedResponseDate());
			} catch (ParseException e) {
				errors.rejectValue(FIELD_REQTD_RESP_DATE, MESSAGE_KEY_REQTD_RESP_DATE_FORMAT);
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private boolean isOtherServiceCategoryChecked(String serviceCategoriesCsv) {
		String otherServiceCategoryId = "";
		boolean retVal = false;
		try {
			List<ServiceCategory> serviceCategories = brandRequestVoMapper.getServiceCategories();
			for (ServiceCategory sc : serviceCategories) {
				if (sc.getSrvcCtgyNm().equalsIgnoreCase(BRPConstants.OTHER)) {
					otherServiceCategoryId = String.valueOf(sc.getSrvcCtgyUid());
				}
			}
			if (serviceCategoriesCsv.contains(otherServiceCategoryId)) {
				retVal = true;
			}
		} catch (ServiceException ex) {

		}
		return retVal;
	}

	/**
	 * Matches the supplied value with the supplied regular expression
	 * 
	 * @param fieldValue
	 *          The text which needs to be matched against the regular expression
	 * @param regexPattern
	 *          Regular expression
	 * @return
	 */
	private boolean isMatchingPattern(String fieldValue, String regexPattern) {
		Matcher matcher = null;
		Pattern pattern = null;
		pattern = Pattern.compile(regexPattern);
		matcher = pattern.matcher(fieldValue);
		return matcher.matches();
	}
	
	
	/**
	 * Validates Q14, Q15, Q16, Q17 in the IPP cascade.
	 * Called from multiple branches of the Q11/Q12/Q13 cascade.
	 */
	private void validateQ14Q15Q16Q17(BrandRequestVo brandRequestVo, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q14_NATL_MEMBERS, MSG_Q14_REQUIRED);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q15_SERVICES_ENTAIL, MSG_Q15_REQUIRED);
		try {
			santizeInput(brandRequestVo.getServiceCategoryServiceEntail());
		} catch (Exception e) {
			// santizeInput already swallows malformed input; ignore here
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q16_PROVIDER_OUTREACH, MSG_Q16_REQUIRED);
		String q16 = brandRequestVo.getCbQ16ProviderOutreachInd();
		if ("Y".equalsIgnoreCase(q16)) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, FIELD_Q17_PROVIDER_OUTREACH_TXT, MSG_Q17_REQUIRED);
			try {
				santizeInput(brandRequestVo.getCbQ17ProviderOutreachTxt());
			} catch (Exception e) {
				// ignore
			}
		}
	}

	private String santizeInput(String input) throws Exception
	{
		if (input != null)
		{
			input = InputSanitizer.sanitize(input);
			//input = input.replaceAll("&quot;", "\"");
			//input = input.replaceAll("&amp;", "&");
			return input;
		}
		return input;
	}
}

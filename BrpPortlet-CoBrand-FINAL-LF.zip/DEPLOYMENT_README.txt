Co-Branding Partner Form - 17-Question Enhancement
FINAL BUILD - All files in LF line endings (matches repo)
====================================================================

CODE FILES (drop into matching paths under wars/BrpPortlet/):
  src/main/java/com/bcbsa/brp/model/BrandRequest.java
  src/main/java/com/bcbsa/brp/vo/BrandRequestVo.java
  src/main/java/com/bcbsa/brp/model/util/BrandRequestVoMapper.java
  src/main/java/com/bcbsa/brp/service/impl/BrandRequestServiceImpl.java
  src/main/java/com/bcbsa/brp/validation/BrpCobrandingFormValidator.java
  src/main/resources/messages.properties
  src/main/webapp/WEB-INF/jsp/BrpPortlet/newCobrandRequest.jsp
  src/main/webapp/WEB-INF/jsp/BrpPortlet/brp-common-preview.jsp
  src/main/webapp/js/main.js

DATABASE SCRIPTS (run once per environment):
  ddl/01_alter_brand_request_add_questions.sql   (23 new columns)
  ddl/02_update_other_service_category.sql        (enable 'Other' as IPP trigger, uses 'Y')

INCLUDED FIXES:
  - 17-question Brand + IPP form (Q1-Q17)
  - Service Categories positioned after Q9
  - Q11 Other cascade: Q14 first, then Q15+Q16
  - Q8 converted to 3 options (Y/E/N) with blocker popup on No
  - Q8 'brand conflict' added to e.g. wording
  - Q1 popup 'unlicensed entity'
  - Q14 question + Q10/Q14/Q16 alerts use "Plan's"
  - Question number prefixes removed (form + preview)
  - All line endings LF (matches repo, clean git diff)

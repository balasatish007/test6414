-- =============================================================================
-- Enable 'Other' service category to trigger IPP questions (Q10-Q17)
-- Uses 'Y' to match existing triggering categories convention.
-- =============================================================================

-- Before
SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED
  FROM service_category WHERE SRVC_CTGY_NM = 'Other';
GO

UPDATE service_category
   SET SRVC_CTGY_QUE_REQUIRED = 'Y'
 WHERE SRVC_CTGY_NM = 'Other';
GO

-- After (expected: Y)
SELECT SRVC_CTGY_NM, SRVC_CTGY_QUE_REQUIRED
  FROM service_category WHERE SRVC_CTGY_NM = 'Other';
GO

-- Rollback:
-- UPDATE service_category SET SRVC_CTGY_QUE_REQUIRED = '1' WHERE SRVC_CTGY_NM = 'Other';
-- GO

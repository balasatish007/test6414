package com.bcbsa.brp.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import com.bcbsa.brp.constants.BRPConstants;
//begin - BW-418
import com.bcbsa.brp.controller.AbstractController;
//end - BW-418
import org.hibernate.SessionFactory;
import org.hibernate.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.bcbsa.brp.dao.GenericDAO;
import com.bcbsa.brp.model.BrandRequest;
import com.bcbsa.brp.model.BrandRequestServiceCategory;
import com.bcbsa.brp.model.BrandRequestServiceCategoryPK;
import com.bcbsa.brp.model.LegalEntity;
import com.bcbsa.brp.model.LegalEntityAssociation;
import com.bcbsa.brp.model.LegalEntityAssociationPK;
import com.bcbsa.brp.model.LegalEntityTradeName;
import com.bcbsa.brp.model.UserUploadCobrandSample;
import com.bcbsa.brp.model.CobrandReviewRules;
import com.bcbsa.brp.model.UserUploadFile;
import com.bcbsa.brp.model.mapper.BrandRequestMapper;
import com.bcbsa.brp.model.util.NotificationBrandRequest;
import com.bcbsa.brp.service.BrandRequestService;
import com.bcbsa.brp.service.LegalEntityAssociationService;
import com.bcbsa.brp.service.LegalEntityTradeNameService;
import com.bcbsa.brp.service.UserUploadCobrandSampleService;
import com.bcbsa.brp.service.UserUploadFileService;
import com.bcbsa.brp.service.exception.ServiceException;
import com.bcbsa.brp.vo.BrandRequestVo;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.workflow.WorkflowHandlerRegistryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;

/**
 * 
 * @author Steve Perry
 * 
 */
@Service
public class BrandRequestServiceImpl  implements BrandRequestService { 

	private static final Log log = LogFactoryUtil.getLog(BrandRequestServiceImpl.class);

	@Autowired
	private GenericDAO<BrandRequest, Integer> brandRequestDAO;

	@Autowired
	private GenericDAO<BrandRequestServiceCategory, Integer> brandRequestServiceCategoryDAO;

	@Autowired
	private LegalEntityAssociationService legalEntityAssociationService;

	@Autowired
	private UserUploadFileService userUploadFileService;

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private UserUploadCobrandSampleService userUploadCobrandSampleService;

	@Autowired
	private LegalEntityTradeNameService legalEntityTradeNameService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bcbsa.brp.service.BrandRequestService#updateStatus(long, int,
	 * int, com.liferay.portal.service.ServiceContext) This method will be
	 * invoked by BrandRequestWorkflowHandler and it will make update to status
	 * of BrandRequest.
	 */
	@Override
	@Transactional
	public BrandRequest updateStatus(long userId, long requestId, int status, String fullName,
			ServiceContext serviceContext) throws ServiceException {
		log.info("Updating status " + status + " fullname " + fullName + " userid:"+ userId );
		try {
			BrandRequest brandRequest = brandRequestDAO.findById(requestId);
			Date currentDate = new Date();
			if(null != brandRequest){
				brandRequest.setStatus(status);
				brandRequest.setStatusByUserId(userId);
				//BRP Phase 1 - Begin
				//OLD:brandRequest.setStatusDate(new Date());
				brandRequest.setStatusDate(currentDate);
				//BRP Phase 1 - End
				brandRequest.setStatusByUserName(fullName);
				if ((status == BRPConstants.APPROVED_STATUS) || (status == BRPConstants.APPROVEDWITHNOTES_STATUS) || (status == BRPConstants.BEPCAPPROVAL_STATUS) || (status == BRPConstants.BEPCAPPROVALWITHNOTES_STATUS)) {
					log.info("Status is approved.");
					log.info("Cobrand Review Type UID: " + brandRequest.getCobrandReviewType().getCobrandRevwTypUid());
					//Get Co-Brand Review Rule corresponding to Co-Brand Review Type UID
					Query query = createdNamedQuery("CobrandReviewRules.findByCBREVIEWTYPEUID").setString("cbReviewTypeUid",brandRequest.getCobrandReviewType().getCobrandRevwTypUid().toString());
					List<CobrandReviewRules> results = query.list();
					//Check if same company was previously submitted in the same level type and was approved
					String temp1 = brandRequest.getLegalEntity().getLegalEntityUid().toString();
					String temp2 = brandRequest.getCobrandReviewType().getCobrandRevwTypUid().toString();
					query = createdNamedQuery("BrandRequest.findByLegalIdStatusLevelType")
							.setString("legalEntityUid", temp1)
							.setString("status1", String.valueOf(BRPConstants.APPROVED_STATUS))
							.setString("status2", String.valueOf(BRPConstants.APPROVEDWITHNOTES_STATUS))
							.setString("status3", String.valueOf(BRPConstants.BEPCAPPROVAL_STATUS))
							.setString("status4", String.valueOf(BRPConstants.BEPCAPPROVALWITHNOTES_STATUS))
							.setString("cobrandRevwTypUid", temp2);
					Date brandRequestOriginalapproval = null;
					if (query.uniqueResult()!= null){
						brandRequestOriginalapproval=(Date)query.uniqueResult();
					}

					Calendar c = Calendar.getInstance();
					if (null != brandRequestOriginalapproval) {					//Same company was previously submitted in the same level type and was approved. Get Approval Date from original request.
						log.info("Approved company with same level type EXISTS....");
						log.info("brandRequest.getCbRenewalDate()"+brandRequest.getCbRenewalDate());
						log.info("Cobrand Review Rules Expiry Period Months value: " + results.get(0).getExpiryPeriodMonths());
						log.info("Original date is: " +brandRequestOriginalapproval);
						if (brandRequest.getCbApprovedDate() == null)
						brandRequest.setCbApprovedDate(brandRequestOriginalapproval);
						c.setTime(brandRequestOriginalapproval); 
					} else {													//Company has never been submitted in this level type and approved
						log.info("Approved company with same level type DOES NOT EXIST....");
						if (null != results) {
							log.info("Cobrand Review Rules Expiry Period Months value: " + results.get(0).getExpiryPeriodMonths()); 
							if (brandRequest.getCbApprovedDate() == null)
							brandRequest.setCbApprovedDate(currentDate);
							c.setTime(currentDate); 
						}
					}
					//for renewal date calculation from current date add expiryperiodmonths
					c.setTime(currentDate);
					c.add(Calendar.MONTH, results.get(0).getExpiryPeriodMonths().intValue());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String sDate= sdf.format(c.getTime());
					Date renewalDate = sdf.parse(sDate);
					if(log.isDebugEnabled())
					{
						log.debug("renewaldate"+ renewalDate+"for"+ brandRequest.getBrandRqstUid());
						log.debug("brandRequest.getCbRenewalDate() before customizations:"+brandRequest.getCbRenewalDate());
					}
					if (brandRequest.getCbRenewalDate() == null)
					brandRequest.setCbRenewalDate(renewalDate);
					log.info("RenewalDate date after customizations is: " +brandRequest.getCbRenewalDate());
					if ((brandRequest.getCobrandReviewType().getCobrandRevwTypUid() == BRPConstants.COBRAND_PREMIER)
							|| (brandRequest.getCobrandReviewType().getCobrandRevwTypUid() == BRPConstants.COBRAND_STRATEGIC)
							|| (brandRequest.getCobrandReviewType().getCobrandRevwTypUid() == BRPConstants.COBRAND_NOTIFICATION_ONLY)
							|| (brandRequest.getCobrandReviewType().getCobrandRevwTypUid() == BRPConstants.COBRAND_NEW_SERVICE_CATEGORY_PREMIER)
							|| (brandRequest.getCobrandReviewType().getCobrandRevwTypUid() == BRPConstants.COBRAND_NEW_SERVICE_CATEGORY_STRATEGIC)) {
						if (brandRequest.getCbSampleUploadActualDate() == null) {
							c.setTime(currentDate); 
							c.add(Calendar.MONTH, BRPConstants.COBRAND_SAMPLE_UPLOAD_MONTHS);
							String tDate= sdf.format(c.getTime());
							Date uploadDueDate = sdf.parse(tDate);
							if (brandRequest.getCbSampleUploadDate() == null)
							brandRequest.setCbSampleUploadDate(uploadDueDate);
						}
					}
				}	
				return brandRequestDAO.update(brandRequest);
			} else {
				return brandRequest;
			}
		} catch (Exception e) {
			throw new ServiceException("Exception occurred while creating BrandRequest!", e);
		}
	}

	@Transactional(readOnly = true)
	@Override
	public BrandRequest fetchBrandRequest(BrandRequest prototype) throws ServiceException {
		BrandRequest ret = null;

		// Grab the Uid
		Long brandRequestUid = prototype.getBrandRqstUid();
		try {
			ret = brandRequestDAO.findById(brandRequestUid);
			log.info("Found BrandRequest by ID: " + brandRequestUid);
		} catch (Exception e) {
			String message = "Exception occurred during fetch request: ";
			log.error(message, e);
			throw new ServiceException(message, e);
		}

		return ret;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateBrandRequest(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
	
		try {
			BrandRequest existingBrandRequest = brandRequestDAO.findById(brandRequest.getBrandRqstUid());
			LegalEntity existingPartnerLegalEntity = existingBrandRequest.getPartnerLegalEntity();
			existingBrandRequest.setBrandUsageDesc(brandRequest.getBrandUsageDesc());
			existingBrandRequest.setCobrandReviewType(brandRequest.getCobrandReviewType());
			existingBrandRequest.setCobrandRenewalType(brandRequest.getCobrandRenewalType());
			existingBrandRequest.setCrntRqstStsUid(brandRequest.getCrntRqstStsUid());
			existingBrandRequest.setInqRqstInd(brandRequest.getInqRqstInd());
			existingBrandRequest.setLegalEntityAssociation(brandRequest.getLegalEntityAssociation());
			existingBrandRequest.setLegalEntityRelationship(brandRequest.getLegalEntityRelationship());

			existingBrandRequest.setPartnerLegalEntity(brandRequest.getPartnerLegalEntity());
			existingBrandRequest.setRequestCategory(brandRequest.getRequestCategory());
			existingBrandRequest.setRqstInqTypUid(brandRequest.getRqstInqTypUid());
			//existingBrandRequest.setStatus(brandRequest.getStatus());
			//existingBrandRequest.setStatusByUserId(brandRequest.getStatusByUserId());
			//existingBrandRequest.setStatusByUserName(brandRequest.getStatusByUserName());
			existingBrandRequest.setUpdatedBy(brandRequest.getUpdatedBy());
			existingBrandRequest.setUpdateTs(brandRequest.getUpdateTs());
			existingBrandRequest.setCobrandReviewFlow(brandRequest.getCobrandReviewFlow());
			LegalEntity newLegalEntity = brandRequest.getLegalEntity();
			existingBrandRequest.getLegalEntity().setBusinessType(newLegalEntity.getBusinessType());
			existingBrandRequest.getLegalEntity().setCityNm(newLegalEntity.getCityNm());
			existingBrandRequest.getLegalEntity().setLegalNm(newLegalEntity.getLegalNm());
			existingBrandRequest.getLegalEntity().setDunsNum(newLegalEntity.getDunsNum());
			// Co-Branding Partner Form 17-question enhancement: only update Group
			// Account Type if the incoming value is non-null. Form no longer
			// collects this field; preserve any existing legacy value.
			if (newLegalEntity.getGroupAccountType() != null) {
				existingBrandRequest.getLegalEntity().setGroupAccountType(newLegalEntity.getGroupAccountType());
			}
			existingBrandRequest.getLegalEntity().setPhoneNum(newLegalEntity.getPhoneNum());
			existingBrandRequest.getLegalEntity().setInactvDt(newLegalEntity.getInactvDt());
			existingBrandRequest.getLegalEntity().setPlan(newLegalEntity.getPlan());
			existingBrandRequest.getLegalEntity().setStreet1Addr(newLegalEntity.getStreet1Addr());
			existingBrandRequest.getLegalEntity().setStreet2Addr(newLegalEntity.getStreet2Addr());
			existingBrandRequest.getLegalEntity().setTpaInd(newLegalEntity.getTpaInd());
			existingBrandRequest.getLegalEntity().setUpdatedBy(newLegalEntity.getUpdatedBy());
			existingBrandRequest.getLegalEntity().setUpdateTs(newLegalEntity.getUpdateTs());
			existingBrandRequest.getLegalEntity().setUsPstlCd(newLegalEntity.getUsPstlCd());
			existingBrandRequest.getLegalEntity().setUsState(newLegalEntity.getUsState());
			existingBrandRequest.getLegalEntity().setUsStateOfIncorporation(newLegalEntity.getUsStateOfIncorporation());
			existingBrandRequest.getLegalEntity().setWebstUrl(newLegalEntity.getWebstUrl());
			existingBrandRequest.setCbStrategicDecisionFact(brandRequest.getCbStrategicDecisionFact());
			existingBrandRequest.setEmailId(brandRequest.getEmailId());
			existingBrandRequest.setCbStrategicRenewRational(brandRequest.getCbStrategicRenewRational());
			existingBrandRequest.setAssocLegalEntity(brandRequest.getAssocLegalEntity());
			
			
			// Handling legal entity trade names
			Set<LegalEntityTradeName> tradeNamesToUpdate = getLegalEntityTradeNamesToUpdate(brandRequest,
					existingBrandRequest);
			existingBrandRequest.getLegalEntity().setLegalEntityTradeNames(tradeNamesToUpdate);
			existingBrandRequest.setBrandRequestServiceCategories(
					getBrandRequestServiceCategoriesToUpdate(brandRequest, existingBrandRequest));

			// Handling attachments
			long repositoryId = (long) liferayContext.get(BRPConstants.SCOPE_GROUP_ID);
			Set<UserUploadFile> files = getUserUploadFilesToUpdate(brandRequest, existingBrandRequest);
			Set<UserUploadCobrandSample> cobrandFiles = getUserCobrandUploadFilesToUpdateCobrand(brandRequest, existingBrandRequest);
			existingBrandRequest.setUserUploadCobrandSample(brandRequest.getUserUploadCobrandSample());
			if(brandRequest.getUserUploadCobrandSample()!=null && !brandRequest.getUserUploadCobrandSample().isEmpty()){
				Set<UserUploadCobrandSample> sampleUsrUploadSet=brandRequest.getUserUploadCobrandSample();
				Iterator<UserUploadCobrandSample> itr=sampleUsrUploadSet.iterator();
				UserUploadCobrandSample uploadSample=itr.next();
				existingBrandRequest.setCbSampleUploadActualDate(uploadSample.getCreateTs());
			}


			// Updating brand request service categories
			for (BrandRequestServiceCategory brsc : existingBrandRequest.getBrandRequestServiceCategories()) {
				brandRequestServiceCategoryDAO.update(brsc);
			}
			//Co-Branding Partner Form 17-question enhancement (update flow) start
			// Service-category questions: 3 reused columns (Q11/Q14/Q15) + flag
			if (brandRequest.getServiceCategoryBlueBenefit() != null) {
				existingBrandRequest.setServiceCategoryBlueBenefit(brandRequest.getServiceCategoryBlueBenefit());
			}
			if (brandRequest.getServiceCategoryNationalAccountMember() != null) {
				existingBrandRequest.setServiceCategoryNationalAccountMember(brandRequest.getServiceCategoryNationalAccountMember());
			}
			if (brandRequest.getServiceCategoryServiceEntail() != null) {
				existingBrandRequest.setServiceCategoryServiceEntail(brandRequest.getServiceCategoryServiceEntail());
			}
			if (brandRequest.getServiceCatQuestionsFlag() != null) {
				existingBrandRequest.setServiceCatQuestionsFlag(brandRequest.getServiceCatQuestionsFlag());
			}

			// Legacy criteria fields: only update if incoming non-null. New
			// submissions leave these null; preserve any legacy value.
			if (brandRequest.getDemoFinancial() != null) {
				existingBrandRequest.setDemoFinancial(brandRequest.getDemoFinancial());
			}
			if (brandRequest.getNoFelonyRecord() != null) {
				existingBrandRequest.setNoFelonyRecord(brandRequest.getNoFelonyRecord());
			}
			if (brandRequest.getReputationBrand() != null) {
				existingBrandRequest.setReputationBrand(brandRequest.getReputationBrand());
			}
			if (brandRequest.getProhibitatedCompany() != null) {
				existingBrandRequest.setProhibitatedCompany(brandRequest.getProhibitatedCompany());
			}
			if (brandRequest.getNoMisuseOfBrands() != null) {
				existingBrandRequest.setNoMisuseOfBrands(brandRequest.getNoMisuseOfBrands());
			}

			// New Q1-Q9 Brand Questions and Q10/Q11other/Q12/Q13/Q16/Q17 IPP fields
			if (brandRequest.getCbQ1LegalNameCnfrmd() != null) existingBrandRequest.setCbQ1LegalNameCnfrmd(brandRequest.getCbQ1LegalNameCnfrmd());
			if (brandRequest.getCbQ2DebitCardInd() != null) existingBrandRequest.setCbQ2DebitCardInd(brandRequest.getCbQ2DebitCardInd());
			if (brandRequest.getCbQ2LicenseAgmtDt() != null) existingBrandRequest.setCbQ2LicenseAgmtDt(brandRequest.getCbQ2LicenseAgmtDt());
			if (brandRequest.getCbQ3ClientListInd() != null) existingBrandRequest.setCbQ3ClientListInd(brandRequest.getCbQ3ClientListInd());
			if (brandRequest.getCbQ3ExceptionAckInd() != null) existingBrandRequest.setCbQ3ExceptionAckInd(brandRequest.getCbQ3ExceptionAckInd());
			if (brandRequest.getCbQ4BrandMisuseInd() != null) existingBrandRequest.setCbQ4BrandMisuseInd(brandRequest.getCbQ4BrandMisuseInd());
			if (brandRequest.getCbQ4MisuseLinksTxt() != null) existingBrandRequest.setCbQ4MisuseLinksTxt(brandRequest.getCbQ4MisuseLinksTxt());
			if (brandRequest.getCbQ4MisuseContactTxt() != null) existingBrandRequest.setCbQ4MisuseContactTxt(brandRequest.getCbQ4MisuseContactTxt());
			if (brandRequest.getCbQ4MisuseAckInd() != null) existingBrandRequest.setCbQ4MisuseAckInd(brandRequest.getCbQ4MisuseAckInd());
			if (brandRequest.getCbQ5NameLogoInfrngInd() != null) existingBrandRequest.setCbQ5NameLogoInfrngInd(brandRequest.getCbQ5NameLogoInfrngInd());
			if (brandRequest.getCbQ5InfrngLinksTxt() != null) existingBrandRequest.setCbQ5InfrngLinksTxt(brandRequest.getCbQ5InfrngLinksTxt());
			if (brandRequest.getCbQ5InfrngContactTxt() != null) existingBrandRequest.setCbQ5InfrngContactTxt(brandRequest.getCbQ5InfrngContactTxt());
			if (brandRequest.getCbQ5InfrngAckInd() != null) existingBrandRequest.setCbQ5InfrngAckInd(brandRequest.getCbQ5InfrngAckInd());
			if (brandRequest.getCbQ6FinlStableInd() != null) existingBrandRequest.setCbQ6FinlStableInd(brandRequest.getCbQ6FinlStableInd());
			if (brandRequest.getCbQ7FelonyInd() != null) existingBrandRequest.setCbQ7FelonyInd(brandRequest.getCbQ7FelonyInd());
			if (brandRequest.getCbQ8NotOnListInd() != null) existingBrandRequest.setCbQ8NotOnListInd(brandRequest.getCbQ8NotOnListInd());
			if (brandRequest.getCbQ9ReputationInd() != null) existingBrandRequest.setCbQ9ReputationInd(brandRequest.getCbQ9ReputationInd());
			if (brandRequest.getCbQ10InterPlanExecTxt() != null) existingBrandRequest.setCbQ10InterPlanExecTxt(brandRequest.getCbQ10InterPlanExecTxt());
			if (brandRequest.getCbQ11OtherTxt() != null) existingBrandRequest.setCbQ11OtherTxt(brandRequest.getCbQ11OtherTxt());
			if (brandRequest.getCbQ12TelehealthSvcInd() != null) existingBrandRequest.setCbQ12TelehealthSvcInd(brandRequest.getCbQ12TelehealthSvcInd());
			if (brandRequest.getCbQ13VirtualOnlyInd() != null) existingBrandRequest.setCbQ13VirtualOnlyInd(brandRequest.getCbQ13VirtualOnlyInd());
			if (brandRequest.getCbQ16ProviderOutreachInd() != null) existingBrandRequest.setCbQ16ProviderOutreachInd(brandRequest.getCbQ16ProviderOutreachInd());
			if (brandRequest.getCbQ17ProviderOutreachTxt() != null) existingBrandRequest.setCbQ17ProviderOutreachTxt(brandRequest.getCbQ17ProviderOutreachTxt());
			//Co-Branding Partner Form 17-question enhancement (update flow) end
			
			brandRequestDAO.update(existingBrandRequest);

			// Updating legal entity association
			List<LegalEntityAssociation> existingAssociations = legalEntityAssociationService
					.getLegalEntityAssociationsByLegalEntityId(
							existingBrandRequest.getLegalEntity().getLegalEntityUid());
			LegalEntityAssociation newAssociation = brandRequest.getLegalEntityAssociation();
			
			
			// Clean up the association table if there
			// is already an entry
			if (existingPartnerLegalEntity != null && newAssociation!=null) {
				deleteExistingLegalEntityAssociations(existingAssociations);
			}
			if (newAssociation != null) {
				// TODO: For some reason, a mere saveOrUpdate doesn't work here.
				// Getting
				// an
				// error that says a different object with the same identifier
				// value
				// was already associated with the session. Need to figure this
				// out
				legalEntityAssociationService.mergeLegalEntityAssociation(newAssociation);
			}

			// If everything goes well, move the files to the folder
			// corresponding to
			// the brand request. This method will only move the files if it
			// could
			// locate the file in the temp folder which could potentially affect
			// the
			// newly added files only
			if (files != null && !files.isEmpty()) {
				userUploadFileService.moveAttachmentsToBrandRequestFolder(repositoryId, brandRequest.getBrandRqstUid(),
						files);
			}
			if (cobrandFiles != null && !cobrandFiles.isEmpty()) {
				userUploadCobrandSampleService.moveAttachmentsToBrandRequestFolder(repositoryId, brandRequest.getBrandRqstUid(),cobrandFiles);
			}

		} catch (Exception ex) {
			throw new ServiceException("Exception occurred while updating BrandRequest!", ex);
		}
	}

	private void deleteExistingLegalEntityAssociations(List<LegalEntityAssociation> existingAssociations)
			throws ServiceException {
		if (existingAssociations != null && !existingAssociations.isEmpty()) {
			// There is only 1 associated-legal-entity for a legal entity
			legalEntityAssociationService.deleteLegalEntityAssociation(existingAssociations.get(0));
		}
	}

	/**
	 * This method returns the list of LegalEntityTradeName objects that contain
	 * existing entries to be retained as well as the new entries to be
	 * inserted.
	 * 
	 * @param brandRequest
	 * @param existingBrandRequest
	 * @return existingTradeNames
	 */
	private Set<LegalEntityTradeName> getLegalEntityTradeNamesToUpdate(BrandRequest brandRequest,
			BrandRequest existingBrandRequest) {
		// Update trade names
		Set<LegalEntityTradeName> existingTradeNames = existingBrandRequest.getLegalEntity().getLegalEntityTradeNames();
		Set<LegalEntityTradeName> newTradeNames = brandRequest.getLegalEntity().getLegalEntityTradeNames();
		Set<String> newTradeNameValues = getTradeNameValueSet(newTradeNames);
		Iterator<LegalEntityTradeName> iter = existingTradeNames.iterator();

		while (iter.hasNext()) {
			LegalEntityTradeName existingTradeName = iter.next();
			String existingTradeNameValue = existingTradeName.getId().getTradeNm();
			if (!newTradeNameValues.contains(existingTradeNameValue)) {
				iter.remove();
				legalEntityTradeNameService.removeTradeName(existingTradeName);
			} else {
				// This trade name is an existing one and needs to be retained.
				// So
				// remove it from the new list.
				removeMatchingTradeName(newTradeNames, existingTradeNameValue);
			}
		}
		for (LegalEntityTradeName let : newTradeNames) {
			// Adding the newly added trade names
			existingTradeNames.add(let);
		}
		return existingTradeNames;
	}

	/**
	 * This method returns the list of BrandRequestServiceCategory objects that
	 * contain existing entries to be retained as well as the new entries to be
	 * inserted.
	 * 
	 * @param brandRequest
	 * @param existingBrandRequest
	 * @return
	 * @throws Exception
	 */
	private Set<BrandRequestServiceCategory> getBrandRequestServiceCategoriesToUpdate(BrandRequest brandRequest,
			BrandRequest existingBrandRequest) throws Exception {
		Set<BrandRequestServiceCategory> existingServiceCategories = existingBrandRequest
				.getBrandRequestServiceCategories();
		Set<BrandRequestServiceCategory> newServiceCategories = brandRequest.getBrandRequestServiceCategories();
		Set<Long> newServiceCategoryIds = getServiceCategoryIdSet(newServiceCategories);
		Iterator<BrandRequestServiceCategory> iter2 = existingServiceCategories.iterator();

		while (iter2.hasNext()) {
			BrandRequestServiceCategory existingServiceCategory = iter2.next();
			long existingServiceCategoryId = existingServiceCategory.getId().getSrvcCtgyUid();
			if (!newServiceCategoryIds.contains(existingServiceCategoryId)) {
				iter2.remove();
				brandRequestServiceCategoryDAO.delete(existingServiceCategory);
			} else {
				// This service category is an existing one and needs to be
				// retained. So
				// remove it from the the newServiceCategories so that it
				// contains only
				// newly added entries.
				if (existingServiceCategory.getServiceCategory().getSrvcCtgyNm().equals(BRPConstants.OTHER)) {
					updateOtherServiceCategoryName(existingServiceCategory, newServiceCategories);
				}
				removeMatchingServiceCategory(newServiceCategories, existingServiceCategoryId);
			}
		}
		for (BrandRequestServiceCategory sc : newServiceCategories) {
			// Adding the newly added ServiceCategory
			existingServiceCategories.add(sc);
		}
		return existingServiceCategories;
	}

	/**
	 * This method will capture the new other service category name so that it
	 * can be updated into the table
	 * 
	 * @param existingServiceCategory
	 * @param newServiceCategories
	 */
	private void updateOtherServiceCategoryName(BrandRequestServiceCategory existingServiceCategory,
			Set<BrandRequestServiceCategory> newServiceCategories) {
		for (BrandRequestServiceCategory brsc : newServiceCategories) {
			if (brsc.getId().getSrvcCtgyUid().equals(existingServiceCategory.getId().getSrvcCtgyUid())) {
				existingServiceCategory.setOthSrvcCtgyNm(brsc.getOthSrvcCtgyNm());
				break;
			}
		}

	}

	/**
	 * This method returns the list of UserUploadFile objects that contain
	 * existing entries to be retained as well as the new entries to be
	 * inserted. Existing entries that don't have to be retained are deleted
	 * also during the process
	 * 
	 * @param brandRequest
	 * @param existingBrandRequest
	 * @return existingAttachments
	 * @throws Exception
	 */
	private Set<UserUploadFile> getUserUploadFilesToUpdate(BrandRequest brandRequest, BrandRequest existingBrandRequest)
			throws Exception {

		Set<UserUploadFile> existingAttachments = existingBrandRequest.getUserUploadFiles();
		Set<UserUploadFile> newAttachments = brandRequest.getUserUploadFiles() == null ? new HashSet<UserUploadFile>()
				: brandRequest.getUserUploadFiles();
		Set<String> newAttachmentValues = getAttachmentValueSet(newAttachments);
		Iterator<UserUploadFile> iter = existingAttachments.iterator();

		while (iter.hasNext()) {
			UserUploadFile existingAttachment = iter.next();
			String existingAttachmentValue = existingAttachment.getId().getLiferayFileEntryId();
			if (!newAttachmentValues.contains(existingAttachmentValue)) {
				iter.remove();
				// It was already deleted from Doc Library when
				// the user deleted it from the UI. So, just delete from the
				// table.
				userUploadFileService.delete(existingAttachment);
			} else {
				// This attachment is an existing one and needs to be retained.
				// So
				// remove it
				// from the newAttachments so that it contains only newly added
				// entries.
				removeMatchingAttachment(newAttachments, existingAttachmentValue);
			}
		}
		for (UserUploadFile uf : newAttachments) {
			// Adding the newly added attachment
			existingAttachments.add(uf);
		}

		return existingAttachments;
	}


	private Set<UserUploadCobrandSample> getUserCobrandUploadFilesToUpdateCobrand(BrandRequest brandRequest, BrandRequest existingBrandRequest)
			throws Exception {

		Set<UserUploadCobrandSample> existingAttachments = existingBrandRequest.getUserUploadCobrandSample();
		Set<UserUploadCobrandSample> newAttachments = brandRequest.getUserUploadFiles() == null ? new HashSet<UserUploadCobrandSample>()
				: brandRequest.getUserUploadCobrandSample();
		Set<String> newAttachmentValues = getAttachmentValueSetCobrand(newAttachments);
		Iterator<UserUploadCobrandSample> iter = existingAttachments.iterator();

		while (iter.hasNext()) {
			UserUploadCobrandSample existingAttachment = iter.next();
			String existingAttachmentValue = existingAttachment.getUserUploadCobrandSamplePK().getLiferayFileEntryId();
			if (!newAttachmentValues.contains(existingAttachmentValue)) {
				iter.remove();
				// It was already deleted from Doc Library when
				// the user deleted it from the UI. So, just delete from the
				// table.
				userUploadCobrandSampleService.delete(existingAttachment);
			} else {
				// This attachment is an existing one and needs to be retained.
				// So
				// remove it
				// from the newAttachments so that it contains only newly added
				// entries.
				removeMatchingAttachmentCobrand(newAttachments, existingAttachmentValue);
			}
		}
		for (UserUploadCobrandSample uf : newAttachments) {
			// Adding the newly added attachment
			existingAttachments.add(uf);
		}

		return existingAttachments;
	}

	private void removeMatchingAttachment(Set<UserUploadFile> newAttachments, String existingAttachmentValue) {
		Iterator<UserUploadFile> iter = newAttachments.iterator();
		while (iter.hasNext()) {
			UserUploadFile attachment = iter.next();
			if (attachment.getId().getLiferayFileEntryId().equals(existingAttachmentValue)) {
				iter.remove();
			}
		}

	}

	private void removeMatchingAttachmentCobrand(Set<UserUploadCobrandSample> newAttachments, String existingAttachmentValue) {
		Iterator<UserUploadCobrandSample> iter = newAttachments.iterator();
		while (iter.hasNext()) {
			UserUploadCobrandSample attachment = iter.next();
			if (attachment.getUserUploadCobrandSamplePK().getLiferayFileEntryId().equals(existingAttachmentValue)) {
				iter.remove();
			}
		}

	}




	private Set<String> getAttachmentValueSet(Set<UserUploadFile> newAttachments) {
		Set<String> attachmentValueSet = new HashSet<String>();
		if (newAttachments != null && !newAttachments.isEmpty()) {
			for (UserUploadFile uf : newAttachments) {
				attachmentValueSet.add(uf.getId().getLiferayFileEntryId());
			}
		}
		return attachmentValueSet;
	}

	private Set<String> getAttachmentValueSetCobrand(Set<UserUploadCobrandSample> newAttachments) {
		Set<String> attachmentValueSet = new HashSet<String>();
		if (newAttachments != null && !newAttachments.isEmpty()) {
			for (UserUploadCobrandSample uf : newAttachments) {
				attachmentValueSet.add(uf.getUserUploadCobrandSamplePK().getLiferayFileEntryId());
			}
		}
		return attachmentValueSet;
	}

	private Set<Long> getServiceCategoryIdSet(Set<BrandRequestServiceCategory> newServiceCategories) {
		Set<Long> serviceCategoryIdSet = new HashSet<Long>();
		for (BrandRequestServiceCategory sc : newServiceCategories) {
			serviceCategoryIdSet.add(sc.getServiceCategory().getSrvcCtgyUid());
		}
		return serviceCategoryIdSet;
	}

	private void removeMatchingTradeName(Set<LegalEntityTradeName> newTradeNames, String existingTradeNameValue) {
		Iterator<LegalEntityTradeName> iter = newTradeNames.iterator();
		while (iter.hasNext()) {
			LegalEntityTradeName tradeName = iter.next();
			if (tradeName.getId().getTradeNm().equals(existingTradeNameValue)) {
				iter.remove();
			}
		}
	}

	private void removeMatchingServiceCategory(Set<BrandRequestServiceCategory> newServiceCategories,
			long existingServiceCategoryId) {
		Iterator<BrandRequestServiceCategory> iter = newServiceCategories.iterator();
		while (iter.hasNext()) {
			BrandRequestServiceCategory brsc = iter.next();
			if (brsc.getServiceCategory().getSrvcCtgyUid() == existingServiceCategoryId) {
				iter.remove();
			}
		}
	}

	private Set<String> getTradeNameValueSet(Set<LegalEntityTradeName> legalEntityTradeNames) {
		Set<String> tradeNameValueSet = new HashSet<String>();
		for (LegalEntityTradeName tn : legalEntityTradeNames) {
			tradeNameValueSet.add(tn.getId().getTradeNm());
		}
		return tradeNameValueSet;
	}

	@Override
	public void withdrawBrandRequest(BrandRequest brandRequest) throws ServiceException {
		throw new ServiceException("The withdrawBrandRequest() method has not yet been implemented!");
	}

	@Override
	@Transactional
	public List<BrandRequest> fetchAll() throws ServiceException {
		try {
			return brandRequestDAO.findAll();
		} catch (Exception e) {
			throw new ServiceException("Exception while fetching the brandrequests.", e);
		}

	}

	@Override
	@Transactional
	public List<BrandRequest> brandRequestsByFilters(String queryName, Map<String, Object> paramMap, int pageNm,
			int pageSz) throws ServiceException {
		log.info("final query being executed for top filter is " + queryName + " Params Map is " + paramMap);
		try {
			return brandRequestDAO.findByQueryParams(queryName, paramMap, pageNm, pageSz);
		} catch (Exception e) {
			throw new ServiceException("Exception while fetching the brandrequests for top filters.", e);
		}
	}


	@Override
	@Transactional
	public List<BrandRequest> brandRequestsByFiltersSQL(String sqlQuery, Map<String, Object> paramMap, int pageNm,
			int pageSz) throws ServiceException {
		log.info("final query being executed for top filter is " + sqlQuery + " Params Map is " + paramMap);
		try {
			List<BrandRequestMapper> resultList=(List<BrandRequestMapper>)brandRequestDAO.findBySQLQueryParams(sqlQuery, paramMap,BrandRequestMapper.class, pageNm, pageSz);
			List<Long> ids=new ArrayList<Long>();
			//List<BrandRequest> brandRequests=new ArrayList<BrandRequest>();
			for(BrandRequestMapper mapper: resultList){
				//brandRequests.add(mapper.toBrandRequest());
				ids.add(mapper.getBrandRqstUid().longValue());
			}
			if(ids.size()>0){
				Map params=new HashMap();
				params.put("brandRqstUids", ids);
				return brandRequestDAO.findByQueryParams("BrandRequest.findByRequestIds",params);
			}else{
				return Collections.EMPTY_LIST;
			}
			//return brandRequests;
		} catch (Exception e)  {
			throw new ServiceException("Exception while fetching the brandrequests for top filters.", e);
		}
	}

	@Transactional
	@Override
	public int countRequestsForFilterSQL(String sqlQuery, Map<String, Object> paramMap) throws ServiceException{

		log.info("final query being executed for top filter is " + sqlQuery+ " Params Map is " + paramMap);
		try {
			return Math.toIntExact(brandRequestDAO.countByQueryParamsSQL(sqlQuery, paramMap));
		} catch (Exception e) {
			throw new ServiceException("Exception while counting the brandrequests for top filters.", e);
		}

	}



	/**
	 * @param id
	 * @return
	 * @throws ServiceException 
	 */
	@Transactional
	@Override
	public BrandRequest findById(long id) throws ServiceException { 
		BrandRequest brandRequest = null;
		try {
			System.out.println("is it in service layer from workflow"+id);
			brandRequest = brandRequestDAO.findById(id);
		
		
		} catch (Exception e) {
			String message = "Exception occurred during fetch request by ID : ";
			log.error(message, e);
			throw new ServiceException(message, e);
		}
		return brandRequest;
	}

	@Override
	@Transactional
	public int countRequestsForFilter(String queryName, Map<String, Object> paramMap) throws ServiceException {
		queryName = queryName + ".count";
		log.info("final query being executed for top filter is " + queryName+ " Params Map is " + paramMap);
		try {
			return Math.toIntExact(brandRequestDAO.countByQueryParams(queryName, paramMap));
		} catch (Exception e) {
			throw new ServiceException("Exception while counting the brandrequests for top filters.", e);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public BrandRequest createBrandRequest(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
		
		BrandRequest ret = null;
		try {
			if(brandRequest.getUserUploadCobrandSample()!=null && !brandRequest.getUserUploadCobrandSample().isEmpty()){
				Set<UserUploadCobrandSample> sampleUsrUploadSet=brandRequest.getUserUploadCobrandSample();
				Iterator<UserUploadCobrandSample> itr=sampleUsrUploadSet.iterator();
				UserUploadCobrandSample uploadSample=itr.next();
				brandRequest.setCbSampleUploadActualDate(uploadSample.getCreateTs());
			}
			BrandRequest persistedBrandRequest = brandRequestDAO.create(brandRequest);
			/*if(persistedBrandRequest.getUserUploadCobrandSample()!=null){
				Set<UserUploadCobrandSample> sampleUsrUploadSet=brandRequest.getUserUploadCobrandSample();
				Iterator<UserUploadCobrandSample> itr=sampleUsrUploadSet.iterator();
				UserUploadCobrandSample uploadSample=itr.next();
				persistedBrandRequest.setCbSampleUploadActualDate(uploadSample.getCreateTs());
				 brandRequestDAO.update(persistedBrandRequest);
			}*/

			// Saving/Updating BrandRequestServiceCategories
			Set<BrandRequestServiceCategory> serviceCategories = persistedBrandRequest
					.getBrandRequestServiceCategories();
			Long requestId = persistedBrandRequest.getBrandRqstUid();
			for (BrandRequestServiceCategory brsc : serviceCategories) {
				BrandRequestServiceCategoryPK pk = new BrandRequestServiceCategoryPK(requestId,
						brsc.getServiceCategory().getSrvcCtgyUid());
				brsc.setId(pk);

				brandRequestServiceCategoryDAO.create(brsc);
			}
			// Saving/Updating LegalEntityAssociation
			LegalEntityAssociation legalEntityAssociation = brandRequest.getLegalEntityAssociation();
			if (legalEntityAssociation != null) {
				LegalEntity legalEntity = persistedBrandRequest.getLegalEntity();
				LegalEntity associatedLegalEntity = persistedBrandRequest.getPartnerLegalEntity();
				String relationshipCode = persistedBrandRequest.getLegalEntityRelationship().getLegalEntityRelshpCd();
				LegalEntityAssociationPK pk = new LegalEntityAssociationPK(legalEntity.getLegalEntityUid(),
						associatedLegalEntity.getLegalEntityUid(), relationshipCode);
				legalEntityAssociation.setId(pk);
				legalEntityAssociationService.createLegalEntityAssociation(legalEntityAssociation);
			}
			ret = persistedBrandRequest;
			if (ret.getUserUploadFiles() != null && !ret.getUserUploadFiles().isEmpty()) {
				// Moving the attachments to a folder identified by the general
				// brand
				// request
				long scopeGroupId = (long) liferayContext.get("SCOPE_GROUP_ID");
				userUploadFileService.moveAttachmentsToBrandRequestFolder(scopeGroupId, brandRequest.getBrandRqstUid(),
						brandRequest.getUserUploadFiles());
			}
			if (ret.getUserUploadCobrandSample() != null && !ret.getUserUploadCobrandSample().isEmpty()) {
				// Moving the attachments to a folder identified by the general
				// brand
				// request
				long scopeGroupId = (long) liferayContext.get("SCOPE_GROUP_ID");
				userUploadCobrandSampleService.moveAttachmentsToBrandRequestFolder(scopeGroupId, brandRequest.getBrandRqstUid(),
						brandRequest.getUserUploadCobrandSample());
				//brandRequestServiceCategoryDAO.update(entity);
			}
		} catch (Exception e) {
			throw new ServiceException("Exception occurred while creating BrandRequest!", e);
		}
		return ret;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public BrandRequest createGeneralBrandRequest(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
		return createNonCoBrandingRequest(brandRequest, liferayContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public BrandRequest createGeneralBrandInquiry(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
		return createNonCoBrandingRequest(brandRequest, liferayContext);
	}

	/**
	 * @param brandRequest
	 * @param liferayContext
	 * @return
	 * @throws ServiceException
	 */
	private BrandRequest createNonCoBrandingRequest(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
		BrandRequest ret = null;
		try {
			BrandRequest persistedBrandRequest = brandRequestDAO.create(brandRequest);

			ret = persistedBrandRequest;
			if (ret.getUserUploadFiles() != null && !ret.getUserUploadFiles().isEmpty()) {
				// Moving the attachments to a folder identified by the general
				// brand
				// request
				long scopeGroupId = (long) liferayContext.get("SCOPE_GROUP_ID");
				userUploadFileService.moveAttachmentsToBrandRequestFolder(scopeGroupId, brandRequest.getBrandRqstUid(),
						brandRequest.getUserUploadFiles());
			}

		} catch (Exception e) {
			throw new ServiceException("Exception occurred while creating BrandRequest!", e);
		}
		return ret;
	}

	/**
	 * Kicks off the workflow.
	 * 
	 * @param brandRequest
	 * @param liferayContext
	 * @throws ServiceException
	 */
	private void initiateWorkflow(BrandRequest brandRequest, Map<String, Object> liferayContext)
			throws ServiceException {
		// Workflow - Start
		log.info("Starting workflow for Brand Request with ID: " + brandRequest.getBrandRqstUid());
		try {
			// The code below needs companyId, groupId, userId from controller.
			// Initiating workflow instance for created BrandRequest
			//begin - BW-418
			ServiceContext serviceContext = (ServiceContext) liferayContext.get(AbstractController.SERVICE_CONTEXT);
			if (Objects.isNull(serviceContext)) { 
				serviceContext = new ServiceContext(); 
				long userId = (Long) liferayContext.get(AbstractController.USER_ID_LONG);
				serviceContext.setUserId(userId); 
			}
			//end - BW-418
			WorkflowHandlerRegistryUtil.startWorkflowInstance((long) liferayContext.get("COMPANY_ID"),(long) liferayContext.get("GROUP_ID"),
					(long) liferayContext.get("SUBMIT_USER_ID_LONG"), BrandRequest.class.getName(),
					brandRequest.getBrandRqstUid(), brandRequest, new ServiceContext());
			// Create Asset mapped to brandrequest -
			AssetEntryLocalServiceUtil.updateEntry((long) liferayContext.get("COMPANY_ID"),
					(long) liferayContext.get("GROUP_ID"), BrandRequest.class.getName(), brandRequest.getBrandRqstUid(),
					null, null);

		} catch (PortalException | SystemException e) {
			log.error(e.getMessage(), e);
			throw new ServiceException(e.getMessage(), e);
		}
		log.info("End of workflow for Brand Request with ID: " + brandRequest.getBrandRqstUid());
		// Workflow - End
	}

	@Override
	@Transactional
	public BrandRequest resolveBrandRequest(long brpId, long repositoryId, Set<UserUploadFile> newAttachments, int status, User user)
			throws ServiceException {
		BrandRequest brandRequest = null;
		try {
			Date now = new Date();
			brandRequest = brandRequestDAO.findById(brpId);
			brandRequest.setStatus(status);
			if(null != user){
				brandRequest.setUpdatedBy(user.getScreenName());
				brandRequest.setStatusByUserId(user.getUserId());
				brandRequest.setStatusByUserName(user.getFullName());
			}
			brandRequest.setStatusDate(now);
			brandRequest.setUpdateTs(now);
			brandRequestDAO.update(brandRequest);
			if (newAttachments != null && !newAttachments.isEmpty()) {
				for (UserUploadFile file : newAttachments) {
					file.setBrandRequest(brandRequest);
					if("User".equalsIgnoreCase((file.getType()))){
						userUploadFileService.create(file);
					}
				}
				userUploadFileService.moveAttachmentsToBrandRequestFolder(repositoryId, brpId, newAttachments);
			}

		} catch (Exception e) {
			throw new ServiceException(e.getMessage(), e);
		}
		return brandRequest;
	}

	@Override
	@Transactional
	public BrandRequest initiateBrandRequestWorkflow(long brandRequestId, Map<String, Object> liferayContext)
			throws ServiceException {
		BrandRequest brandRequest = null;
		try {
			log.info("initiateBrandRequestWorkflow:about to get brandRequest");
			brandRequest = brandRequestDAO.findById(brandRequestId);
			log.info("initiateBrandRequestWorkflow:got brandRequest: "+ brandRequest);
			if (null != brandRequest.getCobrandReviewType()
					&& brandRequest.getCobrandReviewType().getCobrandRevwTypUid() > 0) {
				log.info("Workflow is being initialized for the Brand Request ID:" + brandRequest.getBrandRqstUid());
				initiateWorkflow(brandRequest, liferayContext);
			}
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(), e);
		}
		return brandRequest;
	}

	@Override
	@Transactional
	public long getCountByStatus(Integer status, Long cobrandRevwTypUid) throws ServiceException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("status", status);
		paramMap.put("cobrandRevwTypUid", cobrandRevwTypUid);
		Long count = 0L;
		try {
			count = brandRequestDAO.countByQueryParams("BrandRequest.CountByStatus", paramMap);
			log.info("the count for status: " + status + " review Type UID: " + cobrandRevwTypUid + " is : " + count);
		} catch (Exception e) {
			throw new ServiceException("Unable to get count for the status", e);
		}
		return count;
	}

	@Override
	@Transactional
	public void updateReviewDecision(BrandRequestVo vo) throws ServiceException {
		try {
			BrandRequest brandRequest = brandRequestDAO.findById(vo.getBrandRqstUid());
			brandRequest.setNextBepcMeeting(vo.getNextBepcMeeting());
			brandRequest.setNextPlanMeeting(vo.getNextPlanMeeting());
			brandRequest.setFlagIndependentReview(vo.getFlagIndependentReview());
			brandRequestDAO.merge(brandRequest);
		} catch (Exception e) {
			throw new ServiceException("Problem while updating the updateReviewDecision()", e);
		}
	}

	@Override
	@Transactional
	public void updateGeneralCommentsNsummaryTxt(BrandRequestVo vo) throws ServiceException {
		try {
			BrandRequest brandRequest = brandRequestDAO.findById(vo.getBrandRqstUid());
			if(!StringUtils.isEmpty(vo.getGeneralComments())){
				brandRequest.setGeneralComments(vo.getGeneralComments());
			}
			if(!StringUtils.isEmpty(vo.getSummaryTxt())){
				brandRequest.setSummaryTxt(vo.getSummaryTxt());
			}
			if(!StringUtils.isEmpty(vo.getBlueWebComments())){
				brandRequest.setBlueWebComments(vo.getBlueWebComments());
			}
			brandRequestDAO.merge(brandRequest);
		} catch (Exception e) {
			throw new ServiceException("Problem while updating the updateGeneralCommentsNsummaryTxt()", e);
		}
	}


	@Override
	@Transactional
	public void updateStatusByAdmins(BrandRequestVo vo, User user) throws ServiceException {
		try {
			BrandRequest brandRequest = brandRequestDAO.findById(vo.getBrandRqstUid());
			brandRequest.setStatus(vo.getStatus());
			brandRequest.setUpdateTs(new Date());
			if(null != user){
				brandRequest.setUpdatedBy(user.getScreenName());
				brandRequest.setStatusByUserId(user.getUserId());
				brandRequest.setStatusByUserName(user.getFullName());
			}
			brandRequestDAO.merge(brandRequest);
		} catch (Exception e) {
			throw new ServiceException("Problem while updating the updateGeneralCommentsNsummaryTxt()", e);
		}
	}

	@Override
	@Transactional
	public void updateGenralBrandRequest(BrandRequest vo, User user) throws ServiceException {
		try {
			BrandRequest brandRequest = brandRequestDAO.findById(vo.getBrandRqstUid());
			brandRequest.setBrandUsageDesc(vo.getBrandUsageDesc());
			brandRequest.setRequestCategory(vo.getRequestCategory());
			brandRequest.setUpdateTs(new Date());
			if(null != user){
				brandRequest.setUpdatedBy(user.getScreenName());
				brandRequest.setStatusByUserId(user.getUserId());
				brandRequest.setStatusByUserName(user.getFullName());
			}
			brandRequestDAO.merge(brandRequest);
		} catch (Exception e) {
			throw new ServiceException("Problem while updating the updateGenralBrandRequest()", e);
		}
	}

	/**
	 * Create name query with given queryname
	 * 
	 * @param queryName
	 * @return
	 * @throws Exception
	 */
	private Query createdNamedQuery(String queryName) throws Exception {
		log.debug("Executing method : createdNamedQuery()");
		Query query = sessionFactory.getCurrentSession().getNamedQuery(queryName);
		query.setCacheable(true);
		return query;
	}
	
	@Override
	@Transactional
	public List<NotificationBrandRequest> getNotificationBrandRequests() throws Exception{
		String queryName="select BRAND_RQST_UID as brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where CB_SAMPLE_UPLOAD_DUE_DT = DATEADD(day, 30, CONVERT (date, GETDATE())) and CB_SAMPLE_UPLOAD_ACTUAL_DT is null and COBRAND_REVW_TYP_UID in (7,8,9)";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}
	
	@Override
	@Transactional
	public List<NotificationBrandRequest> getExpiryNotificationBrandRequests() throws Exception{
		String queryName="select BRAND_RQST_UID as brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where CB_SAMPLE_UPLOAD_DUE_DT = DATEADD(day, -1, CONVERT (date, GETDATE())) and CB_SAMPLE_UPLOAD_ACTUAL_DT is null and COBRAND_REVW_TYP_UID in (7,8,9)";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}
	
	@Override
	@Transactional
	public List<NotificationBrandRequest> getRenewalNotificationBrandRequests() throws Exception{
		//BLWBBCBSAUPGD-164 bug fix begin
		String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (30) and CB_RENEWAL_DT is not null and cb_renewal_flg is null and COBRAND_REVW_TYP_UID in (6,7,8) and STATUS in (4,5,16,18)";
		//BLWBBCBSAUPGD-164 bug fix end
		//String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (30) and CB_RENEWAL_DT is not null and COBRAND_REVW_TYP_UID in (6,7,8)";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}
	
	@Override
	@Transactional
	public List<NotificationBrandRequest> getRenewalNotificationBrandRequestsSixMonths() throws Exception{
		//BLWBBCBSAUPGD-164 bug fix begin
		String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (180) and CB_RENEWAL_DT is not null and cb_renewal_flg is null and COBRAND_REVW_TYP_UID in (6,7,8) and STATUS in (4,5,16,18)";
		//BLWBBCBSAUPGD-164 bug fix end
		//String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (180) and CB_RENEWAL_DT is not null and COBRAND_REVW_TYP_UID in (6,7,8)";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}
	
	@Override
	@Transactional
	public List<NotificationBrandRequest> getRenewalNotificationBrandRequestsOneYear() throws Exception{
		//BLWBBCBSAUPGD-164 bug fix begin
		String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (365) and CB_RENEWAL_DT is not null and cb_renewal_flg is null and COBRAND_REVW_TYP_UID in (6,7,8) and STATUS in (4,5,16,18)";
		//BLWBBCBSAUPGD-164 bug fix end
		//String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getDate(), CB_RENEWAL_DT) in (365) and CB_RENEWAL_DT is not null and COBRAND_REVW_TYP_UID in (6,7,8)";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}


	@Override
	@Transactional
	public void updateBrandRequest(BrandRequest brandRequest)
			throws ServiceException {
		
		try {
			brandRequestDAO.update(brandRequest);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	@Transactional
	public void updateGBRDerivativeRemainder(BrandRequestVo vo) throws ServiceException {
		try {
			Calendar c = Calendar.getInstance();
			
			BrandRequest brandRequest = brandRequestDAO.findById(vo.getBrandRqstUid());
			if(!StringUtils.isEmpty(vo.getGbrDerivativeApprovalDate())){
				brandRequest.setGbrDerivativeApprovalDate(vo.getGbrDerivativeApprovalDate());
			}
			if(!StringUtils.isEmpty(vo.getGbrSendRemainder())){
				brandRequest.setGbrSendRemainder(vo.getGbrSendRemainder());
			}
			if(!StringUtils.isEmpty(vo.getGbrDerivativeApprovalDate())){
				c.setTime(vo.getGbrDerivativeApprovalDate()); 
				c.add(Calendar.DATE, 180);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String sDate= sdf.format(c.getTime());
				Date remainderDate = sdf.parse(sDate);
				brandRequest.setGbrDerivativeRemainderDate(remainderDate);
			}
			brandRequestDAO.merge(brandRequest);
		} catch (Exception e) {
			throw new ServiceException("Problem while updating the updateGBRDerivativeRemainder()", e);
		}
	}

	@Override
	@Transactional
	public List<NotificationBrandRequest> getDerivativeRequestNotifications() throws Exception{
		String queryName="select distinct BRAND_RQST_UID AS brandRequestId,CREATED_BY as createdBy from BRAND_REQUEST where datediff(day,getdate(),dateadd(day,-30,GBR_DERIVATIVE_REMAINDER_DT))='150' and GBR_DERIVATIVE_REMAINDER_DT is not null and RQST_CTGY_UID in (19) and status='7' and GBR_SEND_REMAINDER='1'";
		Map queryParameters=null;
		List<NotificationBrandRequest> brandRequests= brandRequestDAO.findBySQLQueryParams(queryName, queryParameters, NotificationBrandRequest.class);
		return brandRequests;
	}
	
	//BLWBBCBSAUPGD-165 changes begin
	@Override
	@Transactional
	public List<BrandRequestVo> findRenewalHistoryByBrandReqId(long brandRequestId,long initParentBrandRequestid) throws Exception{
		Query query = createdNamedQuery("BrandRequest.findRenewalHistoryByRequestId")
				.setLong("intlParentBrandRqstUid",initParentBrandRequestid)
				.setLong("brandRqstUid", brandRequestId)
				.setLong("intlBrandRqstUid", initParentBrandRequestid);
		List<BrandRequest> results = query.list();
		List<BrandRequestVo> renewalHistoryList=new ArrayList<BrandRequestVo>();
		DateFormat df = new SimpleDateFormat(BRPConstants.MM_DD_YYYY);
		if(results!=null && results.size()>0)
		{
			BrandRequestVo renewalHistory= new BrandRequestVo();
			BrandRequest brFirstRecord=results.get(0);
			
			//first record populating begin
			
				log.info("brandRequest history details populating begin for first record"+ brFirstRecord.getBrandRqstUid());
				renewalHistory.setBrandRqstUid(brFirstRecord.getBrandRqstUid());
				renewalHistory.setIntlParentBrandRqstUid(brFirstRecord.getIntlParentBrandRqstUid());
				renewalHistory.setParentBrandRqstUid(brFirstRecord.getParentBrandRqstUid());
				renewalHistory.setCreateTs(df.format(brFirstRecord.getCreateTs()));
				
				if(brFirstRecord!=null && brandRequestId>brFirstRecord.getBrandRqstUid())
				{
				renewalHistory.setMaxRecord(false);
				}
				else 
				{
					renewalHistory.setMaxRecord(true);
				}
				renewalHistoryList.add(renewalHistory);
				log.info("brandRequest history details populating end first record"+ brFirstRecord.getBrandRqstUid());
			
			
			//first record populating end
			
			for(BrandRequest br:results.subList(1, results.size()))
			{
				renewalHistory= new BrandRequestVo();
				
				
				log.info("brandRequest history details populating begin"+ br.getBrandRqstUid());
				renewalHistory.setBrandRqstUid(br.getBrandRqstUid());
				renewalHistory.setIntlParentBrandRqstUid(br.getIntlParentBrandRqstUid());
				renewalHistory.setParentBrandRqstUid(br.getParentBrandRqstUid());
				renewalHistory.setCreateTs(df.format(br.getCreateTs()));
				renewalHistory.setMaxRecord(false);
				log.info("brandRequest history details populating end"+ br.getBrandRqstUid());
				renewalHistoryList.add(renewalHistory);
				
				
			}
			
			
		}
		log.info("Final Renewal history size "+renewalHistoryList.size()+ "for original brand request id"+brandRequestId);
		return renewalHistoryList;
	}
	//BLWBBCBSAUPGD-165 changes end
	
}


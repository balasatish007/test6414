$(document).ready(function() {
	var $validator = $('#brandRequestForm').validate();
	
	//service categories questions enhnancement start
	var checkboxArray= [];
	// Build initial array from any pre-checked checkboxes (defensive: skip empty values)
	document.querySelectorAll("#serviceCategoriesDiv input[type='checkbox']:checked").forEach(function(checkbox){
		var v = checkbox.value;
		if (v !== null && v !== undefined && String(v).trim() !== '') {
			checkboxArray.push(String(v).trim());
		}
	});
	if (checkboxArray.length > 0) {
		showDiv(checkboxArray);  // single call with full set, not per-checkbox
	}
	
	var serviceCatQuestionsFlag=document.getElementById('serviceCatQuestionsFlag') != undefined;
		
	if(serviceCatQuestionsFlag && document.getElementById('serviceCatQuestionsFlag').value == "Y")
	{
			$("#serviceCategoryQuestions").show();
	}
	if(serviceCatQuestionsFlag && document.getElementById('serviceCatQuestionsFlag').value == "N")
	{
			$("#serviceCategoryQuestions").hide();
			// Removed reference to criteriaRequirement element (no longer in DOM after 17-question enhancement)
	}
	
	
	$("#serviceCategoriesDiv input[type='checkbox']").change(function(){
		// Rebuild the checked-checkbox array from scratch on every change
		// (fixes pre-existing bugs: ':unchecked' isn't a real jQuery selector,
		//  and Array.pop(value) doesn't remove a specific value)
		checkboxArray = [];
		$("#serviceCategoriesDiv input[type='checkbox']:checked").each(function () {
			var v = $(this).val();
			if (v !== null && v !== undefined && String(v).trim() !== '') {
				checkboxArray.push(String(v).trim());
			}
		});
		showDiv(checkboxArray);
	});
	//service categories questions enhnancement end
	// Cobranding Criteria Requirement customisation removed - 17-question enhancement
	$.validator.addMethod(
		'alpha',
		function(value, element) {
			return this.optional(element) || /^[a-zA-Z]+$/i.test(value);
		},
		'Please enter alphabets only'
	);

	$('#applyRequestBtn').click(
		function() {
			var reviewType = $('#cobrandRevwTypUid option:selected').text();
			//alert('apply request button'+reviewType);
			//$('#brandRequestForm').submit();
		}
	);

	$('#saveForLaterBtn').click(
		function() {
			$('#brandRequestForm').attr(
				'action',
				$('#saveForLaterBrandRequest').val()
			);
			$('#brandRequestForm').submit();
		}
	);

	$('#applyGeneralBrandRequestBtn').click(
		function(){
			//BLWBBCBSAUPGD-137 changes begin
			//$('#generalBrandRequestForm').submit();
			//BLWBBCBSAUPGD-137 changes end
		}
	);

	$('#discardRequestBtn').click(
		function() {
			window.location.href = '/web/blueweb_new/about-the-blue-system';
		}
	);

	$('#add_trade_name').click(
		function(event) {
			addTradeNameField(event);
		}
	);

	$('#remove_trade_name').click(
		function(event) {
			removeTradeNameField(event);
		}
	);

	$('#brandRequestReviewSubmitBtn').click(
		function() {
			$('#brandRequestReviewForm').submit();
		}
	);

	$('#brandRequestEditBtn').click(function() {
		$('#brandRequestReviewForm').attr(
			'action',
			$('#brandRequestEditBtnUrl').val()
		);

		$('#brandRequestReviewForm').submit();
	});

	// Below is used in MyHistory

	$('#advancedResultsFilterBtn').click(function() {
		$('#advancedFiltering').submit();
	});

	$('#cobrnadAdvancedResultsFilterBtn').click(function() {
		$('#cobrandAdvancedFiltering').submit();
	});

	$('#filterResultsTypeReport').click(function() {
		$('#applyTopFilteringReport').submit();
	});
	$('#advancedResultsFilterBtnReport').click(function() {
		$('#advancedFilteringReport').submit();
	});

	$('#filterResultsType').click(function() {
		$('#applyTopFiltering').submit();
	});
	$('#filterResultsType').click(function() {
		$('#applyTopFiltering').submit();
	});

	$('#closeWindowBtn').click(function() {
		// alert('closed clicked.');

		$('#brpLeEditModelWindow').dialog('close');
	});

	$('#legalName').autocomplete({
		select: function(event, ui) {
			event.preventDefault();

			$('#legalName').val(ui.item.value.name);

			$('#legalNameUid').val(ui.item.value.leUid);

			$('#businessType option[value="' + ui.item.value.requestType + '"]').attr('selected', true);

			$('#stateIncorp option[value="' + ui.item.value.stateOfInCorp + '"]').attr('selected', true);

			$('#address1').val(ui.item.value.streetOne);

			$('#address2').val(ui.item.value.StreetTwo);

			$('#city').val(ui.item.value.cityName);

			$('#usStateCd option[value="' + ui.item.value.stateCode + '"]').attr('selected', true);

			$('#zipCode').val(ui.item.value.zipCode);

			$('#dunsNum').val(ui.item.value.dunsNum);

			$('#webSite').val(ui.item.value.website);

			$('#phoneNum').val(ui.item.value.phoneNum);

			if (ui.item.value.tpaInd == '1') {
				$('#isTpa1').prop('checked', true);
			}
			else {
				$('#isTpa2').prop('checked', true);
			}

			if (ui.item.value.planCode == '') {
				$('#isUnlicensed2').prop('checked', true);
			}
			else {
				$('#isUnlicensed1').prop('checked', true);

				$('#planCodes option[value="' + ui.item.value.planCode + '"]').attr('selected', true);
			}

			$('#serviceCategoriesDiv input[type=checkbox]').each(
				function() {
					if (ui.item.value.serviceCategoriesIds.indexOf('___' + $(this).val() + '___') >= 0) {
						$(this).prop('checked', true);
						
					}
					$(this).prop('readonly', true);
				}
			);

			var tradeNamesArr = ui.item.value.tradeNames.split('___');

			$('#tradeNamesContainer').html('');

			$('#tradeNamesContainer').append('<input id="tradeNames-1" name="tradeNames" class="tradeNameClass" type="text" value="">');

			if (tradeNamesArr.length >= 1) {
				$('.tradeNameClass').val(tradeNamesArr[0]);
			}

			if (tradeNamesArr.length > 1) {
				for (var i = 1; i < tradeNamesArr.length - 2; i++) {
					$('#tradeNamesContainer').append('<br><input id="tradeNames-' + i + 1 + ' name="tradeNames" class="tradeNameClass" type="text" value="' + tradeNamesArr[i] + '">');
				}
			}

			$('#legalNameUid').prop('readonly', true);

			$('#businessType option:not(:selected)').prop('disabled', true);

			$('#stateIncorp option:not(:selected)').prop('disabled', true);

			$('#address1').prop('readonly', true);

			$('#address2').prop('readonly', true);

			$('#city').prop('readonly', true);

			$('#usStateCd option:not(:selected)').prop('disabled', true);

			$('#zipCode').prop('readonly', true);

			$('#dunsNum').prop('readonly', true);

			$('#webSite').prop('readonly', true);

			$('#phoneNum').prop('readonly', true);

			$('#isTpa').prop('readonly', true);

			// $('#planCodes option:not(:selected)').prop('disabled', true);

			// Make an ajax call to update the categories.

			makeAnAjaxCall('POST', $('#getUpdatedCategoriesUrl').val(), 'serviceCategoriesDiv', 'legalEntityUid=' + ui.item.value.leUid);
		},
		source: function(request, response) {
			$.ajax({
				data: {
					searchKey: request.term
				},
				dataType: 'json',
				success: function(data) {
					response($.map(data, function(v) {
						return {
							label: v.name,
							value: v
						};
					}));
				},
				type: 'POST',
				url: $('#getLegalNameSuggestionsURL').val(),
			});
		}
	});

	$('#typeAheadUserNameTxt').autocomplete({
		minLength: 3,
		select: function(event, ui) {
			event.preventDefault();

			$('#customUserName').val(ui.item.value);

			$('#typeAheadUserNameTxt').val(ui.item.label);
		},
		source: function(request, response) {
			$.ajax({
				data: {
					searchKey: request.term
				},
				dataType: 'json',
				success: function(data) {
					response(
						$.map(
							data,
							function(v) {
								return {
									label: v.fullName,
									value: v.userName
								};
							}
						)
					);
				},
				type: 'POST',
				url: $('#getUserNameSuggestionsURL').val()
			});
		}
	});

	$('#otherServiceCategoryId').keypress(
		function() {
			$('.service_categories input[type="checkbox"]').each(
				function() {
					$(this).prop('checked', false);
				}
			);

			$('#otherCheckbox').prop('checked', true);
		}
	);


	$('#gb-inq-discard-confir-dialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#gb-inq-confir-dialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#coBrandDiscardReqDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#coBrandDiscardReqPreviewDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#discardGbrDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#withDrawGbrDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});

	$('#resolveGbrCommentsDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});
	$('#resolveInqCommentsDialog').dialog({
		autoOpen: false,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		}
	});
});

// Below is used in MyHistory

$(function() {
	$('#myHrFromDate').datepicker({
		numberOfMonths: 1,
		onSelect: function(selected) {
			var dt = new Date(selected);

			dt.setDate(dt.getDate() + 1);

			$('#myHrToDate').datepicker('option', 'minDate', dt);
		}
	});

	$('#myHrToDate').datepicker({
		numberOfMonths: 1,
		onSelect: function(selected) {
			var dt = new Date(selected);

			dt.setDate(dt.getDate() - 1);

			$('#myHrFromDate').datepicker('option', 'maxDate', dt);
		}
	});
});

function showBrandRequestDetailsWindow(brpId, isWindowClose, event) {
	if (!isWindowClose) {
		event.preventDefault();
	}

	$('body').css('overflow', 'hidden');

	$('#brpDetailsModelWindow').html('loading...');

	$('#brpDetailsModelWindow').dialog({
		close: function() {
			$('body').css({
				overflow: 'inherit'
			});
			if (isWindowClose) {
				window.close();
			}
		},
		height: $(window).height(),
		open: function() {
			$('body').css({
				overflow: 'hidden'
			});
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		resizable: false,
		width: $('#main-content').width(),
		cache: false
		
	});
	


	makeAnAjaxCall('POST', $('#getBrpDetailsById').val(), 'brpDetailsModelWindow', 'brpId=' + brpId);
}

function leEditDialog(leId, isWindowClose, event) {
	if (!isWindowClose) {
		event.preventDefault();
	}

	$('body').css('overflow', 'hidden');

	$('#brpLeEditModelWindow').html('loading...');

	$('#brpLeEditModelWindow').dialog({
		close: function() {
			$('body').css('overflow', 'inherit');

			if (isWindowClose) {
				window.close();
			}
		},
		height: $(window).height(),
		open: function() {
			$('body').css('overflow', 'hidden');

			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		resizable: false,
		width: $('#main-content').width()
	});

	makeAnAjaxCall('POST', $('#brpLeEditModelUrl').val(), 'brpLeEditModelWindow', 'leId=' + leId);
}

function updateReviewDecision(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateReviewDecisionUrl', 'updateReviewDecisionResult', 'updateReviewDecisionFrm', 1);
}

function updateGeneralComments(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateGeneralCommentsUrl', 'updateGeneralCommentsResult', 'updateGeneralCommentsFrm', 1);
}

function updateBlueWebComments(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateBlueWebCommentsUrl', 'updateBlueWebCommentsResult', 'updateBlueWebCommentsFrm', 1);
}

function updateSummaryTxt(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateSummaryTxtUrl', 'updateSummaryTxtResult', 'updateSummaryTextFrm', 1);
}

function updateStatusByOnlyAdmins(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateStatusByOnlyAdminsUrl', 'updateStatusByOnlyAdminsResult', 'updateStatusByOnlyAdminsFrm', 1);
}

function submitCompEditForm() {
	$('#brpLeEditModelWindow').scrollTop(0);

	$('#loadingImageDialog').show();

	var dataStr1 = 'legalEntityUid=' + $('#legalEntityUid').val() + '&commentsType=brandComments&brandComments=' + $('#brandComments').val();
	var dataStr2 = 'legalEntityUid=' + $('#legalEntityUid').val() + '&commentsType=legalComments&legalComments=' + $('#legalComments').val();
	var dataStr3 = 'legalEntityUid=' + $('#legalEntityUid').val() + '&commentsType=licensureComments&licensureComments=' + $('#licensureComments').val();
	var dataStr4 = 'legalEntityUid=' + $('#legalEntityUid').val() + '&commentsType=generalCompanyDescription&generalCompanyDescription=' + $('#generalCompanyDescription').val();

	makeAnAjaxCall('POST', $('#saveCommentsURL').val(), 'dummyStatusField', dataStr1);

	window.setTimeout(
		function() {
			makeAnAjaxCall('POST', $('#saveCommentsURL').val(), 'dummyStatusField', dataStr2);
		},
		500
	);

	window.setTimeout(
		function() {
			makeAnAjaxCall('POST', $('#saveCommentsURL').val(), 'dummyStatusField', dataStr3);
		},
		1000
	);

	window.setTimeout(
		function() {
			makeAnAjaxCall('POST', $('#saveCommentsURL').val(), 'dummyStatusField', dataStr4);
		},
		1500
	);

	window.setTimeout(
		function() {
			fromSubmitAjaxCallWithCloseLoading('POST', 'companySaveFormUrl', 'statusContainerDiv', 'editCompanyDetailsForm', 1);
		},
		2000
	);
}

function resolveGeneralBrandRequestSubmit() {
	fromSubmitAjaxCall('POST', 'resolveGeneralBrandRequestId', 'resolveGeneralBrandRequestDiv', 'resolveGeneralBrandRequestForm');
}

function withdrawGeneralBrandRequestSubmit(urlId) {
	$("#assignToMeGeneralBrand").attr("disabled", true);
	fromSubmitAjaxCall('POST', urlId, 'resolveGeneralBrandRequestDiv', 'resolveGeneralBrandRequestForm');
}

function resolveGeneralBrandInquirySubmit() {
	fromSubmitAjaxCall('POST', 'resolveGeneralBrandInquiryId', 'resolveGeneralBrandInquiryDiv', 'resolveGeneralBrandInquiryForm');
}

function withdrawGeneralBrandInquirySubmit(urlId) {
	$("#assignToMeGeneralBrandInquiry").attr("disabled", true);
	fromSubmitAjaxCall('POST', urlId, 'resolveGeneralBrandInquiryDiv', 'resolveGeneralBrandInquiryForm');
}

function closeCompEditForm() {
	$('.ui-dialog-titlebar-close').click();
}

function cloneTradeNameNOrder() {
	var clonedEle = $('#tradeNameDiv')
		.children()
		.last()
		.clone();

	clonedEle.val('');

	$('#tradeNameDiv')
		.children()
		.last()
		.after(clonedEle);

	$('#tradeNameDiv')
		.children()
		.each(
			function(index) {
				$(this).attr('name', 'tradeNames[' + index + ']');
			}
		);
}

function makeAnAjaxCall(typeStr, urlStr, resultsDivId, dataStr) {
	var request = $.ajax({
		dataType: 'html',
		type: typeStr,
		url: urlStr + '&' + dataStr
	});

	request.done(
		function(msg) {
			$('#' + resultsDivId).html(msg);
		}
	);

	request.fail(
		function() {
			$('#' + resultsDivId).html('<b>Sorry! there was a problem while processing your request.</b>');
		}
	);
}

function fromSubmitAjaxCall(typeStr, hiddenInputId, resultsDivId, formId) {
	fromSubmitAjaxCallWithCloseLoading(typeStr, hiddenInputId, resultsDivId, formId, 0);
}

function fromSubmitAjaxCallWithCloseLoading(typeStr, hiddenInputId, resultsDivId, formId, hideDiag) {
	var dataStr = $('#' + formId).serialize();
	var urlStr = $('#' + hiddenInputId).val();

	var request = $.ajax({
		dataType: 'html',
		type: typeStr,
		url: urlStr + '&' + dataStr
	});

	request.done(
		function(msg) {
			$('#' + resultsDivId).html(msg);

			if (hideDiag > 0) {
				$('#loadingImageDialog').hide();
			}
		}
	);

	request.fail(
		function() {
			$('#' + resultsDivId).html('<b>Sorry! there was a problem while processing your request.</b>');

			if (hideDiag > 0) {
				$('#loadingImageDialog').hide();
			}
		}
	);
}

// Add More Trade Name fields

function addTradeNameField(event) {
	event.preventDefault();

	var n = $('.tradeNameClass').length + 1;

	var $newTradeNameField = $('</br><input id="tradeNames-' + n + '" name="tradeNames" class="tradeNameClass" placeholder="Trade Name" type="text" value="" aria-required="true">');
	var $tradeNameGroup = $('#tradeNamesContainer');

	$tradeNameGroup.append($newTradeNameField);
}

function removeTradeNameField(event) {
	event.preventDefault();

	// var $tradeNameGroup = $("label#trade_names");

	var n = $('.tradeNameClass').length;

	var fieldToRemove = $('#tradeNames-' + n);

	// $tradeNameGroup.remove(fieldToRemove);

	fieldToRemove.remove();
}

// Opening the modal dialog to upload the attachment for brandrequest

$(function() {
	$('#attachment-dialog').dialog({
		autoOpen: false,
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Upload': function(evt) {
				evt.preventDefault();

				var myFormData = new FormData($('#myUploadForm')[0]);

				myFormData.append(
					'fileDescription',
					$('#fileDescription').val()
				);
				myFormData.append(
					'file',
					$('#fileData').val()
				);

				$('#loadingImageDialog').show();

				$.ajax({
					contentType: false,
					data: myFormData,
					dataType: 'json',
					enctype: 'multipart/form-data',
					error: function(result) {
						$('#loadingImageDialog').hide();

						$('#attachment-error').text(result['responseText']);
					},
					processData: false,
					success: function(result) {
						$('#loadingImageDialog').hide();

						refreshAttachmentTable(result);

						$('#attachment-dialog').dialog('close');
					},
					type: 'POST',
					url: $('#myUploadForm').attr('action')
				});
			}

		},
		close: function() {
			$('#fileDescription').val('');
		},
		height: 350,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		showErrors: function() {
			$('#attachment-dialog').dialog('open');

			this.defaultShowErrors();
		},
		width: 395
	});

	$('.upload_link').click(
		function(evt) {
			evt.preventDefault();

			$('#attachment-dialog').dialog('open');
		}
	);

	$('#attachment-cobrand-dialog').dialog({
		autoOpen: false,
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Upload': function(evt) {
				evt.preventDefault();

				// debugger;

				var myFormData = new FormData($('#myCobrandUploadForm')[0]);

				myFormData.append(
					'fileDescription',
					$('#cobrandfileDescription').val()
				);
				myFormData.append(
					'file',
					$('#cobrandfileData').val()
				);

				$('#loadingImageDialog').show();

				$.ajax({
					contentType: false,
					data: myFormData,
					dataType: 'json',
					enctype: 'multipart/form-data',
					error: function(result) {
						$('#loadingImageDialog').hide();

						$('#attachment-error').text(result['responseText']);
					},
					processData: false,
					success: function(result) {
						$('#loadingImageDialog').hide();

						refreshAttachmentTable(result);

						$('#attachment-cobrand-dialog').dialog('close');
					},
					type: 'POST',
					url: $('#myCobrandUploadForm').attr('action')
				});
			}
		},
		close: function() {
			$('#fileDescription').val('');
		},
		height: 350,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		showErrors: function() {
			$('#attachment-cobrand-dialog').dialog('open');

			this.defaultShowErrors();
		},
		width: 395
	});

	$('.cobrand_upload_link').click(
		function(evt) {
			evt.preventDefault();

			$('#attachment-cobrand-dialog').dialog('open');
		}
	);

	$('#attachment-stategic-dialog').dialog({
		autoOpen: false,
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Upload': function(evt) {
				evt.preventDefault();

				var myFormData = new FormData($('#mystategicUploadForm')[0]);

				myFormData.append(
					'fileDescription',
					$('#stategicfileDescription').val()
				);
				myFormData.append(
					'file',
					$('#stategicfileData').val()
				);

				$('#loadingImageDialog').show();

				$.ajax({
					contentType: false,
					data: myFormData,
					dataType: 'json',
					enctype: 'multipart/form-data',
					error: function(result) {
						$('#loadingImageDialog').hide();

						$('#attachment-error').text(result['responseText']);
					},
					processData: false,
					success: function(result) {
						$('#loadingImageDialog').hide();

						refreshAttachmentTable(result);

						$('#attachment-stategic-dialog').dialog('close');
					},
					type: 'POST',
					url: $('#mystategicUploadForm').attr('action') + '&fileType=3'
				});
			}
		},
		close: function() {
			$('#fileDescription').val('');
		},
		height: 350,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		showErrors: function() {
			$('#attachment-stategic-dialog').dialog('open');

			this.defaultShowErrors();
		},
		width: 395
	});

	$('.upload_stategic_link').click(function(evt) {
		evt.preventDefault();

		$('#attachment-stategic-dialog').dialog('open');
	});
});

// Add the details of the newly uploaded file entry in the attachment table in the parent brand request form

function refreshAttachmentTable(data) {
	if (typeof (data['fileName']) != 'undefined' && typeof (data['fileDescription']) != 'undefined' && typeof (data['fileId']) != 'undefined') {
		var rowIndex = $('#attachment_table tr').length - 1;

		$('<tr id = "' + data['fileId'] + '"/>').html(
			'<td>' +
				'<input type="hidden" name="attachmentList[' + rowIndex + '].fileName" value="' + data['fileName'] + '"/>' +
				'<input type="hidden" name="attachmentList[' + rowIndex + '].fileDescription" value="' + data['fileDescription'] + '"/>' +
				'<input type="hidden" name="attachmentList[' + rowIndex + '].fileId" value="' + data['fileId'] + '"/>' +
				'<input type="hidden" name="attachmentList[' + rowIndex + '].type" value="' + data['type'] + '"/>' +
				'<input type="hidden" name="attachmentList[' + rowIndex + '].fileType" value="' + data['fileType'] + '"/>' +
				data['fileName'] +
			'</td>' +
			'<td>' +
				data['fileDescription'] +
			'</td>' +
			'<td>' +
				'<a href="#" class="util_link confirm_delete">Delete</a>' +
			'</td>')
			.appendTo('#attachment_table');
	}

	reIndexAttachmentTable();
}

function reIndexAttachmentTable() {
	$('#attachment_table')
		.find('tr:gt(0)')
		.each(
			function(i, row) {
				var $row = $(row);
				var $hiddenTds = $row.find('input:hidden');

				var rowIndex = $(this).index() - 1;

				$hiddenTds.each(
					function(i, hiddenTd) {
						if ($(hiddenTd).attr('name').indexOf('.fileName') >= 0) {
							$(hiddenTd).attr('name', 'attachmentList[' + rowIndex + '].fileName');
						}

						if ($(hiddenTd).attr('name').indexOf('.fileDescription') >= 0) {
							$(hiddenTd).attr('name', 'attachmentList[' + rowIndex + '].fileDescription');
						}

						if ($(hiddenTd).attr('name').indexOf('.fileId') >= 0) {
							$(hiddenTd).attr('name', 'attachmentList[' + rowIndex + '].fileId');
						}
					}
				);
			}
		);
}

$(document).on(
	'click',
	'.confirm_delete',
	function(event) {
		event.preventDefault();

		// var rowIndex = $(this).closest('td').parent()[0].sectionRowIndex - 1;

		var trId = $(this).closest('tr').attr('id');

		$('#fileid-to-delete').val(trId);

		$('#delete-confirmation').dialog({
			buttons: {
				'Keep it': function() {
					$(this).dialog('close');
				},
				'Yes, delete it': function() {
					var deleteAttachmentFormData = new FormData($('#attachmentDeleteForm')[0]);

					deleteAttachmentFormData.append(
						'fileId',
						$('#fileid-to-delete').val()
					);
					
					

					$.ajax({
						contentType: false,
						data: deleteAttachmentFormData,
						dataType: 'json',
						enctype: 'multipart/form-data',
						error: function(result) {
							console.log(result['status']);
						},
						processData: false,
						success: function(result) {
							if (result['status'] == 'success') {
								$('table#attachment_table tr#' + trId).remove();

								reIndexAttachmentTable();
							}
							$('#delete-confirmation').dialog('close');
						},
						type: 'POST',
						url: $('#attachmentDeleteForm').attr('action')
					});
				}
			}
		});

		$('#delete-confirmation').dialog('open');
	}
);

function withdrawGeneralBrandInquirySubmitClick(urlId, event) {
	event.preventDefault();

	$('#userCommentsWithTextArea').val('');

	$('#gb-inq-confir-dialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Confirm': function() {
				var userComments = $('#userCommentsWithTextArea').val();

				$('#userComments').val(userComments);

				withdrawGeneralBrandInquirySubmit(urlId);

				$(this).dialog('close');
			},
		}
	});

	$('#gb-inq-confir-dialog').dialog('open');
}


function resolveGeneralBrandInquirySubmitClick(event) {
	event.preventDefault();

	$('#userCommentsTextArea').val('');

	$('#resolveInqCommentsDialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Resolve': function() {
				var userComments = $('#userCommentsTextArea').val();

				$('#userComments').val(userComments);

				resolveGeneralBrandInquirySubmit();

				$(this).dialog('close');
			}
		}
	});

	$('#resolveInqCommentsDialog').dialog('open');
}

function discardGeneralBrandInquiryClick(event) {
	event.preventDefault();
	
	$('#gb-inq-discard-confir-dialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Confirm': function() {
				window.location.href = $('#discardGbrUrl').attr('href');
				$('#attachment_table').find('tr:gt(0)').each(function () {
				
					var trId = $(this).closest('tr').attr('id');
					
						$('#fileid-to-delete').val(trId);
						var deleteAttachmentFormData = new FormData($('#attachmentDeleteForm')[0]);

						deleteAttachmentFormData.append(
							'fileId',
									$('#fileid-to-delete').val()
								);
								
								

								$.ajax({
									contentType: false,
									data: deleteAttachmentFormData,
									dataType: 'json',
									enctype: 'multipart/form-data',
									error: function(result) {
										console.log(result['status']);
									},
									processData: false,
									
									type: 'POST',
									url: $('#attachmentDeleteForm').attr('action')
								});
						
					
	            })
	         
				
				$(this).dialog('close');
			}
		}
	});
	$('#gb-inq-discard-confir-dialog').dialog('open');
	
}

function coBrandDiscardReqClick(event) {
	event.preventDefault();

	$('#coBrandDiscardReqDialog').dialog({
		buttons: {
			'Cancel': function() {
				window.location.href = $('#coBrandDiscardReq').attr('href');

				$(this).dialog('close');
			},
			'Confirm': function() {
				window.location.href = $('#coBrandDiscardReq').attr('href');
				$('#attachment_table').find('tr:gt(0)').each(function () {
					var trId = $(this).closest('tr').attr('id');
					
						$('#fileid-to-delete').val(trId);
						var deleteAttachmentFormData = new FormData($('#attachmentDeleteForm')[0]);

						deleteAttachmentFormData.append(
							'fileId',
									$('#fileid-to-delete').val()
								);
								
								

								$.ajax({
									contentType: false,
									data: deleteAttachmentFormData,
									dataType: 'json',
									enctype: 'multipart/form-data',
									error: function(result) {
										console.log(result['status']);
									},
									processData: false,
									
									type: 'POST',
									url: $('#attachmentDeleteForm').attr('action')
								});
						
					
	            })

				$(this).dialog('close');
			}
		}
	});

	$('#coBrandDiscardReqDialog').dialog('open');
}

function coBrandDiscardReqOnPreviewClick(event) {
	event.preventDefault();

	$('#coBrandDiscardReqPreviewDialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Confirm': function() {
				$('#submitWithdrawRequestFrm').submit();
				$(this).dialog('close');
			}
		},
		width: 500
	});

	$('#coBrandDiscardReqPreviewDialog').dialog('open');
}

function discardGbrClick(event) {
	event.preventDefault();

	$('#discardGbrDialog').dialog({
		buttons: {
			'Cancel': function() {
				$('#userCommentsId').val('');

				$(this).dialog('close');
			},
			'Confirm': function() {
				window.location.href = $('#discardGbrUrl').attr('href');
			
				$('#attachment_table').find('tr:gt(0)').each(function () {
					var trId = $(this).closest('tr').attr('id');
					
						$('#fileid-to-delete').val(trId);
						var deleteAttachmentFormData = new FormData($('#attachmentDeleteForm')[0]);

						deleteAttachmentFormData.append(
							'fileId',
									$('#fileid-to-delete').val()
								);
								
								

								$.ajax({
									contentType: false,
									data: deleteAttachmentFormData,
									dataType: 'json',
									enctype: 'multipart/form-data',
									error: function(result) {
										console.log(result['status']);
									},
									processData: false,
									
									type: 'POST',
									url: $('#attachmentDeleteForm').attr('action')
								});
						
					
	            })


				$(this).dialog('close');
			}
		}
	});

	$('#discardGbrDialog').dialog('open', 'resize', 'auto');
}

function discardGbrDetailsClick(urlId, event) {
	event.preventDefault();

	$('#userCommentsWithTextArea').val('');

	$('#discardGbrDialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Confirm': function() {
				var userComments = $('#userCommentsWithTextArea').val();

				$('#userComments').val(userComments);

				withdrawGeneralBrandRequestSubmit(urlId);

				$(this).dialog('close');
			}
		}
	});

	$('#discardGbrDialog').dialog('open');
}

function withdrawGbrDetailsClick(urlId, event) {
	event.preventDefault();

	$('#userCommentsWithTextArea').val('');

	$('#withDrawGbrDialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Confirm': function() {
				var userComments = $('#userCommentsWithTextArea').val();

				$('#userComments').val(userComments);

				withdrawGeneralBrandRequestSubmit(urlId);

				$(this).dialog('close');
			}
		}
	});

	$('#withDrawGbrDialog').dialog('open');
}

function resolveGbrDetailsClick(event) {
	event.preventDefault();

	$('#userCommentsTextArea').val('');

	$('#resolveGbrCommentsDialog').dialog({
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Resolve': function() {
				var userComments = $('#userCommentsTextArea').val();

				$('#userComments').val(userComments);

				resolveGeneralBrandRequestSubmit();

				$(this).dialog('close');
			}
		}
	});

	$('#resolveGbrCommentsDialog').dialog('open');
}

function saveCobrandFile(brandRequestId, fileVo) {
	var url = $('#saveCobrandFileId').val();

	url += '&brandRequestId=' + brandRequestId;

	$('#fileName').val(fileVo.fileName);

	$('#fileId').val(fileVo.fileId);

	$('#type').val(fileVo.type);

	$('#fileType').val(fileVo.fileType);

	$('#fileDescription').val(fileVo.fileDescription);

	$('#brandRequestCobrandForm').attr('action', url);

	$('#brandRequestCobrandForm').submit();

	/* $.ajax({
		url : url,
		type : "POST",
		data : JSON.stringify(fileVo),
		contentType:false,
		dataType : 'json',
		processData: false,
		success : function(result) {
		alert("cobrand file saved suceesfully");
		},
		error : function(result){
		$('#loadingImageDialog').hide();
		$('#attachment-error').text(result['responseText']);
		}
	});
	*/
}

function cobranduploadLink(brandRequestId) {
	$('#attachment-cobrand-table-dialog').dialog({
		autoOpen: false,
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Upload': function(evt) {
				evt.preventDefault();

				var myFormData = new FormData($('#myCobrandUploadForm')[0]);

				myFormData.append(
					'fileDescription',
					$('#cobrandfileDescription').val()
				);
				myFormData.append(
					'file',
					$('#cobrandfileData').val()
				);

				$('#loadingImageDialog').show();

				$.ajax({
					contentType: false,
					data: myFormData,
					dataType: 'json',
					enctype: 'multipart/form-data',
					error: function(result) {
						$('#loadingImageDialog').hide();
						$('#attachment-error').text(result['responseText']);
					},
					processData: false,
					success: function(result) {
						$('#loadingImageDialog').hide();
						saveCobrandFile(brandRequestId, result);
						$('#attachment-cobrand-table-dialog').dialog('close');
					},
					type: 'POST',
					url: $('#myCobrandUploadForm').attr('action')
				});
			}
		},
		close: function() {
			$('#fileDescription').val('');
		},
		height: 350,
		modal: true,
		open: function() {
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		showErrors: function() {
			$('#attachment-cobrand-table-dialog').dialog('open');

			this.defaultShowErrors();
		},
		width: 395
	});

	$('#attachment-cobrand-table-dialog').dialog('open');

	/*
	$(".cobrand_upload_table_link").click(function(e) {
		e.preventDefault();
		$("#attachment-cobrand-table-dialog").dialog("open");
	});
	*/
}
//BLWBBCBSAUPGD-135 fix begin
function submitReviewCobrandRequest()
{
	
	document.getElementById('brandRequestReviewForm').submit();
	//BLWBBCBSAUPGD-160 changes begin
	$("#brandRequestReviewSubmitBtn").attr("disabled", true);
	//BLWBBCBSAUPGD-160 changes end
	
	
}
function submitNewCobrandRequest()
{
	document.getElementById('brandRequestForm').submit();
	//BLWBBCBSAUPGD-140 changes begin(disable button after click)
	$("#applyRequestBtn").attr("disabled", true);
	//BLWBBCBSAUPGD-140 changes end
}

//BLWBBCBSAUPGD-135 fix end

//BLWBBCBSAUPGD-137 fix begin
function submitNewGeneralBrandRequest()
{
	document.getElementById('generalBrandRequestForm').submit();
	//BLWBBCBSAUPGD-140 changes begin(disable button after click)
	$("#applyGeneralBrandRequestBtn").attr("disabled", true);
	//BLWBBCBSAUPGD-140 changes end
	
}
function editExistingCobrandRequest()
{
	//$('#brandRequestReviewForm').attr(
		//	'action',
		//	$('#brandRequestEditBtnUrl').val()
		//);
	document.getElementById("brandRequestReviewForm").setAttribute("action", document.getElementById('brandRequestEditBtnUrl').value);
	document.getElementById('brandRequestReviewForm').submit();
}
function saveForLaterCobrandRequest()
{
		document.getElementById("brandRequestForm").setAttribute("action", document.getElementById('saveForLaterBrandRequest').value);
		document.getElementById('brandRequestForm').submit();
}
//BLWBBCBSAUPGD-137 fix end
//BLWBBCBSAUPGD-140 changes begin(disable button after click)
function submitReviewGeneralBrandRequest()
{
	document.getElementById('generalBrandRequestReviewForm').submit();
	
	$("#genernalBrandRequestReviewSubmitBtn").attr("disabled", true);
	
	
	
}
//BLWBBCBSAUPGD-140 changes end
//BLWBBCBSAUPGD-143 changes begin

function updateGBRDerivativeRemainder(event) {
	event.preventDefault();

	$('#loadingImageDialog').show();

	fromSubmitAjaxCallWithCloseLoading('POST', 'updateGBRDerivativeRemainderUrl', 'updateGBRDerivativeRemainderResult', 'updateGBRDerivativeRemainderFrm', 1);
}

//BLWBBCBSAUPGD-143 changes end



//BLWBBCBSAUPGD-165 changes begin

function showBrandRequestDetailsWindowForHistory(brpId, isWindowClose, event) {
	if (!isWindowClose) {
		event.preventDefault();
	}

	$('body').css('overflow', 'hidden');

	$('#brpRenewActivityDetailsModelWindow').html('loading...');

	$('#brpRenewActivityDetailsModelWindow').dialog({
		close: function() {
			$('body').css({
				overflow: 'inherit'
			});
			if (isWindowClose) {
				window.close();
			}
		},
		height: $(window).height(),
		open: function() {
			$('body').css({
				overflow: 'hidden'
			});
			$('.ui-button-icon-only', '.ui-dialog-titlebar')
				.removeClass('ui-button-icon-only')
				.addClass('ui-button-icon');
		},
		resizable: false,
		width: $('#main-content').width(),
		cache: false
		
	});
	


	makeAnAjaxCall('POST', $('#getBrpDetailsById').val(), 'brpRenewActivityDetailsModelWindow', 'brpId=' + brpId+'&noPopUp=true');
}
//BLWBBCBSAUPGD-165 changes end

// service Category Questions customisation start
function showDiv(array) {
	// Defensive: filter out empty/null/non-numeric values
	// (pre-existing change handler can leave empty strings in the array,
	//  which the server then fails to Long.valueOf, killing the cascade)
	var cleaned = [];
	if (array && array.length) {
		for (var i = 0; i < array.length; i++) {
			var v = array[i];
			if (v !== null && v !== undefined && String(v).trim() !== '' && !isNaN(parseInt(v, 10))) {
				cleaned.push(String(v).trim());
			}
		}
	}
	// Deduplicate (the pre-existing code can also leave duplicates)
	cleaned = cleaned.filter(function (v, i, a) { return a.indexOf(v) === i; });

	if (cleaned.length === 0) {
		// Nothing valid selected - hide IPP questions and bail out
		$("#serviceCatQuestionsFlag").val("N");
		$("#serviceCategoryQuestions").hide();
		clearIppCascade();
		return;
	}

	AUI().use('aui-io-request',
		function (aui) {
			AUI().io.request($('#serviceCatQuestions').val(), {
				method: 'POST',
				dataType: 'json',
				data: {
					serviceCategoryId: JSON.stringify(cleaned)
				},
				on: {
					success: function () {
						if (this.get('responseData') == true) {
							$("#serviceCatQuestionsFlag").val("Y");
							$("#serviceCategoryQuestions").show();
							refreshQ11Cascade();
							$("#stateOfIncorporation").css({ 'margin-top': '0px' });
						} else {
							$("#serviceCatQuestionsFlag").val("N");
							$("#serviceCategoryQuestions").hide();
							clearIppCascade();
							$("#stateOfIncorporation").css({ 'margin-top': '0px' });
						}
					},
					failure: function () {
						// Server error - don't lock the user out
						console.warn('serviceCatQuestions request failed');
						$("#serviceCatQuestionsFlag").val("N");
						$("#serviceCategoryQuestions").hide();
					}
				}
			});
		}
	);
}
// service Category Questions customisation end


// =============================================================================
// Co-Branding Partner Form 17-question enhancement start
// =============================================================================

$(document).ready(function () {

	// ----- Date picker for Q2 license agreement date -----
	if ($('#cbQ2LicenseAgmtDt').length) {
		$('#cbQ2LicenseAgmtDt').datepicker({
			numberOfMonths: 1,
			changeMonth: true,
			changeYear: true,
			yearRange: 'c-50:c+50'
		});
	}

	// ----- Q1: Hard-stop pop-up if "No" -----
	$(document).on('change', 'input[name="cbQ1LegalNameCnfrmd"]', function () {
		if ($(this).val() === 'N' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ1BlockerDialog');
			$('input[name="cbQ1LegalNameCnfrmd"]').prop('checked', false);
		}
	});

	// ----- Q2: Show/hide date field on Yes -----
	$(document).on('change', 'input[name="cbQ2DebitCardInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ2DateBlock').show();
			$('#cbQ2NoInfo').hide();
		} else if ($(this).val() === 'N') {
			$('#cbQ2DateBlock').hide();
			$('#cbQ2NoInfo').show();
			// Preserve previously entered date on toggle
		}
	});

	// ----- Q3: Show/hide acknowledgement checkbox on Yes -----
	$(document).on('change', 'input[name="cbQ3ClientListInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ3AckBlock').show();
		} else {
			$('#cbQ3AckBlock').hide();
			$('input[name="cbQ3ExceptionAckInd"]').prop('checked', false);
		}
	});

	// ----- Q4: Show/hide sub-fields on Yes -----
	$(document).on('change', 'input[name="cbQ4BrandMisuseInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ4Subfields').show();
		} else {
			$('#cbQ4Subfields').hide();
			$('#cbQ4MisuseLinksTxt, #cbQ4MisuseContactTxt').val('');
			$('input[name="cbQ4MisuseAckInd"]').prop('checked', false);
		}
	});

	// ----- Q5: Show/hide sub-fields on Yes -----
	$(document).on('change', 'input[name="cbQ5NameLogoInfrngInd"]', function () {
		if ($(this).val() === 'Y') {
			$('#cbQ5Subfields').show();
		} else {
			$('#cbQ5Subfields').hide();
			$('#cbQ5InfrngLinksTxt, #cbQ5InfrngContactTxt').val('');
			$('input[name="cbQ5InfrngAckInd"]').prop('checked', false);
		}
	});

	// ----- Q6: Hard-stop pop-up if "No" -----
	$(document).on('change', 'input[name="cbQ6FinlStableInd"]', function () {
		if ($(this).val() === 'N' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ6BlockerDialog');
			$('input[name="cbQ6FinlStableInd"]').prop('checked', false);
		}
	});

	// ----- Q7: Hard-stop pop-up if "Yes" -----
	$(document).on('change', 'input[name="cbQ7FelonyInd"]', function () {
		if ($(this).val() === 'Y' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ7BlockerDialog');
			$('input[name="cbQ7FelonyInd"]').prop('checked', false);
		}
	});

	// ----- Q8: Hard-stop pop-up if "No" -----
	$(document).on('change', 'input[name="cbQ8NotOnListInd"]', function () {
		if ($(this).val() === 'N' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ8BlockerDialog');
			$('input[name="cbQ8NotOnListInd"]').prop('checked', false);
		}
	});

	// ----- Q9: Hard-stop pop-up if "Yes" -----
	$(document).on('change', 'input[name="cbQ9ReputationInd"]', function () {
		if ($(this).val() === 'Y' && $(this).is(':checked')) {
			showCbBlockerDialog('#cbQ9BlockerDialog');
			$('input[name="cbQ9ReputationInd"]').prop('checked', false);
		}
	});

	// ----- Q11/Q12/Q13/Q16 cascade -----
	$(document).on('change', 'input[name="serviceCategoryBlueBenefit"]', function () { refreshQ11Cascade(); });
	$(document).on('change', 'input[name="cbQ12TelehealthSvcInd"]', function () { refreshQ12Cascade(); });
	$(document).on('change', 'input[name="cbQ13VirtualOnlyInd"]', function () { refreshQ13Cascade(); });
	$(document).on('change', 'input[name="cbQ16ProviderOutreachInd"]', function () {
		var v = $('input[name="cbQ16ProviderOutreachInd"]:checked').val();
		if (v === 'Y') { $('#cbQ17Block').show(); }
		else { $('#cbQ17Block').hide(); $('#cbQ17ProviderOutreachTxt').val(''); }
	});

	// Q14 change handler: when Q14 answered on Q11=Other path, reveal Q15 and Q16
	$(document).on('change', 'input[name="serviceCategoryNationalAccountMember"]', function () {
		var q11 = $('input[name="serviceCategoryBlueBenefit"]:checked').val();
		if (q11 === 'OTHER') {
			$('#cbQ15Block').show();
			$('#cbQ16Block').show();
		}
	});

	if ($('#serviceCategoryQuestions').is(':visible')) { refreshQ11Cascade(); }
	restoreBrandQuestionSubfields();
});

// =============================================================================
// Helper functions
// =============================================================================

function showCbBlockerDialog(dialogSelector) {
	$(dialogSelector).dialog({
		modal: true, width: 500,
		buttons: { 'OK': function () { $(this).dialog('close'); } }
	});
}

function refreshQ11Cascade() {
	var q11 = $('input[name="serviceCategoryBlueBenefit"]:checked').val();
	$('#cbQ11OtherBlock').hide();
	$('#cbQ12Block').hide();
	$('#cbQ13Block').hide();
	$('#cbQ14Block').hide();
	$('#cbQ15Block').hide();
	$('#cbQ16Block').hide();
	$('#cbQ17Block').hide();

	if (q11 === 'CARVEOUT') { clearQ11Other(); clearQ12to17(); }
	else if (q11 === 'CLAIM') { clearQ11Other(); $('#cbQ12Block').show(); refreshQ12Cascade(); }
	else if (q11 === 'OTHER') {
		$('#cbQ11OtherBlock').show();
		// Only Q14 appears initially; Q15+Q16 appear once Q14 is answered
		$('#cbQ14Block').show();
		// If Q14 already has an answer (e.g. loading saved request), show Q15+Q16 too
		if ($('input[name="serviceCategoryNationalAccountMember"]:checked').val()) {
			$('#cbQ15Block').show();
			$('#cbQ16Block').show();
			if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') { $('#cbQ17Block').show(); }
		}
	}
}

function refreshQ12Cascade() {
	var q12 = $('input[name="cbQ12TelehealthSvcInd"]:checked').val();
	$('#cbQ13Block').hide(); $('#cbQ14Block').hide(); $('#cbQ15Block').hide(); $('#cbQ16Block').hide(); $('#cbQ17Block').hide();
	if (q12 === 'Y') { $('#cbQ13Block').show(); refreshQ13Cascade(); }
	else if (q12 === 'N') {
		$('#cbQ14Block').show(); $('#cbQ15Block').show(); $('#cbQ16Block').show();
		if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') { $('#cbQ17Block').show(); }
	}
}

function refreshQ13Cascade() {
	var q13 = $('input[name="cbQ13VirtualOnlyInd"]:checked').val();
	$('#cbQ14Block').hide(); $('#cbQ15Block').hide(); $('#cbQ16Block').hide(); $('#cbQ17Block').hide();
	if (q13 === 'N') {
		$('#cbQ14Block').show(); $('#cbQ15Block').show(); $('#cbQ16Block').show();
		if ($('input[name="cbQ16ProviderOutreachInd"]:checked').val() === 'Y') { $('#cbQ17Block').show(); }
	}
}

function clearQ11Other() { $('#cbQ11OtherTxt').val(''); }

function clearQ12to17() {
	$('input[name="cbQ12TelehealthSvcInd"]').prop('checked', false);
	$('input[name="cbQ13VirtualOnlyInd"]').prop('checked', false);
	$('input[name="serviceCategoryNationalAccountMember"]').prop('checked', false);
	$('#serviceCategoryServiceEntail').val('');
	$('input[name="cbQ16ProviderOutreachInd"]').prop('checked', false);
	$('#cbQ17ProviderOutreachTxt').val('');
}

function clearIppCascade() {
	$('#cbQ10InterPlanExecTxt').val('');
	$('input[name="serviceCategoryBlueBenefit"]').prop('checked', false);
	clearQ11Other();
	clearQ12to17();
}

function restoreBrandQuestionSubfields() {
	if ($('input[name="cbQ2DebitCardInd"]:checked').val() === 'Y') { $('#cbQ2DateBlock').show(); }
	if ($('input[name="cbQ2DebitCardInd"]:checked').val() === 'N') { $('#cbQ2NoInfo').show(); }
	if ($('input[name="cbQ3ClientListInd"]:checked').val() === 'Y') { $('#cbQ3AckBlock').show(); }
	if ($('input[name="cbQ4BrandMisuseInd"]:checked').val() === 'Y') { $('#cbQ4Subfields').show(); }
	if ($('input[name="cbQ5NameLogoInfrngInd"]:checked').val() === 'Y') { $('#cbQ5Subfields').show(); }
}

// =============================================================================
// Co-Branding Partner Form 17-question enhancement end
// =============================================================================

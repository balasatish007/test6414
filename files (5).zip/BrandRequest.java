package com.bcbsa.brp.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The persistent class for the brand_request database table.
 * 
 */
@Entity
@Table(name = "brand_request")

@NamedQueries({
		//@NamedQuery(name = "BrandRequest.SubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType is not null and (:createdBy is null OR b.createdBy = :createdBy) order by b.brandRqstUid desc"),
		////BLWBBCBSAUPGD-165 changes begin ( excluded inactive records)
		@NamedQuery(name = "BrandRequest.SubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType is not null and (:createdBy is null OR b.createdBy = :createdBy) and (b.status not in (25)) order by b.createTs desc"),
		//@NamedQuery(name = "BrandRequest.NewSubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType in (7,8) and b.requestActivity in (4,5) and (:createdBy is null OR b.createdBy = :createdBy) order by b.brandRqstUid desc"),
		/*
		@NamedQuery(name = "BrandRequest.SubmittedByMyPlan", query = "from BrandRequest b where b.cobrandReviewType is not null and b.partnerLegalEntity.legalEntityUid in (:leIdsList) order by b.brandRqstUid desc"),
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:createdBy is null OR b.createdBy = :createdBy) order by b.brandRqstUid desc"),
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMyPlan", query = "from BrandRequest b where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) order by b.brandRqstUid desc"),
		*/
		@NamedQuery(name = "BrandRequest.SubmittedByMyPlan", query = "from BrandRequest b where b.cobrandReviewType is not null and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (b.status not in (25)) order by b.createTs desc"),
		//BLWBBCBSAUPGD-165 changes end
		//BLWBBCBSAUPGD-140 reporting changes begin
		//BLWBBCBSAUPGD-149 reporting changes begin
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMe", query = "from BrandRequest b  where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:createdBy is null OR b.createdBy = :createdBy) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in (:serviceCategory ))  or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) order by b.createTs desc"),
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMyPlan", query = "from BrandRequest b  where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in  (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) order by b.createTs desc"),
		//BLWBBCBSAUPGD-165 changes begin
		@NamedQuery(name = "BrandRequest.Advanced.Renew.SubmittedByMe", query = "from BrandRequest b  where b.cobrandReviewType is not null and ( (:status is null OR b.status = :status) OR (b.intlParentBrandRqstUid is not null and b.status not in (25) ) )  and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:createdBy is null OR b.createdBy = :createdBy) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in (:serviceCategory ))  or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) order by b.createTs desc"),
		@NamedQuery(name = "BrandRequest.Advanced.Renew.SubmittedByMyPlan", query = "from BrandRequest b  where b.cobrandReviewType is not null and ( (:status is null OR b.status = :status) OR (b.intlParentBrandRqstUid is not null and b.status not in (25) ) )  and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in  (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) order by b.createTs desc"),
		//BLWBBCBSAUPGD-165 changes end
		//BLWBBCBSAUPGD-149 reporting changes end
		//BLWBBCBSAUPGD-140 reporting changes end

		//BLWBBCBSAUPGD-165 changes begin ( excluded inactive records)
		@NamedQuery(name = "BrandRequest.SubmittedByMe.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is not null and (:createdBy is null OR b.createdBy = :createdBy) and (b.status not in (25))"),
		@NamedQuery(name = "BrandRequest.SubmittedByMyPlan.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is not null and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (b.status not in (25))"),
		//BLWBBCBSAUPGD-165 changes end
		//BLWBBCBSAUPGD-140 reporting changes begin
		//BLWBBCBSAUPGD-149 reporting changes begin
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMe.count", query = "select count(*) from BrandRequest b  where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:createdBy is null OR b.createdBy = :createdBy) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in  (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) "),
		@NamedQuery(name = "BrandRequest.Advanced.SubmittedByMyPlan.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is not null and (:status is null OR b.status = :status) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c))"),
		//BLWBBCBSAUPGD-165 changes begin
		@NamedQuery(name = "BrandRequest.Advanced.Renew.SubmittedByMe.count", query = "select count(*) from BrandRequest b  where b.cobrandReviewType is not null and ( (:status is null OR b.status = :status) OR (b.intlParentBrandRqstUid is not null and b.status not in (25) ) ) and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:createdBy is null OR b.createdBy = :createdBy) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in  (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c)) "),
		@NamedQuery(name = "BrandRequest.Advanced.Renew.SubmittedByMyPlan.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is not null and ( (:status is null OR b.status = :status) OR (b.intlParentBrandRqstUid is not null and b.status not in (25) ) )  and (:businessType is null OR b.legalEntity.businessType.busTypCd = :businessType) and (:cobrandReviewType is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandReviewType) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:legalName is null OR lower(b.legalEntity.legalNm) like lower('%'+:legalName+'%')) and (:requestId is null OR b.brandRqstUid =:requestId) and (b.brandRqstUid in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c where c.serviceCategory.srvcCtgyNm in (:serviceCategory)) or b.brandRqstUid not in (select c.id.brandRqstUid from BrandRequest br join br.brandRequestServiceCategories c))"),
		//BLWBBCBSAUPGD-165 changes end
		//BLWBBCBSAUPGD-149 reporting changes end
		//BLWBBCBSAUPGD-140 reporting changes end

		/*
		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and (:createdBy is null OR b.createdBy = :createdBy) order by b.brandRqstUid desc"),
		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMyPlan", query = "from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) order by b.brandRqstUid desc"),
		*/
		//BLWBBCBSAUPGD-140 reporting changes begin
		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMe", query = "from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and (:createdBy is null OR b.createdBy = :createdBy) and (:planSubmitted is null OR lower(b.submitterPlanName) = lower(:planSubmitted)) and (:requestId is null OR b.brandRqstUid =:requestId) order by b.createTs desc"),
		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMyPlan", query = "from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:planSubmitted is null OR lower(b.submitterPlanName) = lower(:planSubmitted)) and (:requestId is null OR b.brandRqstUid =:requestId) order by b.createTs desc"),

		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMe.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and (:createdBy is null OR b.createdBy = :createdBy) and (:planSubmitted is null OR lower(b.submitterPlanName) = lower(:planSubmitted)) and (:requestId is null OR b.brandRqstUid =:requestId)"),
		@NamedQuery(name = "NonCoBrandRequest.SubmittedByMyPlan.count", query = "select count(*) from BrandRequest b where b.cobrandReviewType is null and b.inqRqstInd = :inqRqstInd and (:status is null OR b.status = :status) and (:currentUser is null OR b.updatedBy = :currentUser) and (:fromDate is null OR b.createTs >= :fromDate) and (:toDate is null OR b.createTs <= :toDate) and (:rqstCtgyUid is null OR b.requestCategory.rqstCtgyUid = :rqstCtgyUid) and b.partnerLegalEntity.legalEntityUid in (:leIdsList) and (:planSubmitted is null OR lower(b.submitterPlanName) = lower(:planSubmitted)) and (:requestId is null OR b.brandRqstUid =:requestId)"),
		//BLWBBCBSAUPGD-140 reporting changes count
		@NamedQuery(name = "BrandRequest.CountByStatus", query = "select count(*) from BrandRequest b where b.cobrandReviewType is not null and (:cobrandRevwTypUid is null OR b.cobrandReviewType.cobrandRevwTypUid = :cobrandRevwTypUid) and b.status = :status"),
		@NamedQuery(name = "BrandRequest.findByLegalIdStatusLevelType", query = "select min(b.cbApprovedDate) from BrandRequest b where b.legalEntity = :legalEntityUid and (b.status = :status1 or b.status = :status2 or b.status = :status3 or b.status = :status4) and b.cobrandReviewType = :cobrandRevwTypUid"),
		@NamedQuery(name = "BrandRequest.findAll", query = "select b from BrandRequest b"),
		@NamedQuery(name = "BrandRequest.findByRequestId", query = "select b from BrandRequest b where b.brandRqstUid =:brandRqstUid"),
		@NamedQuery(name = "BrandRequest.findByRequestIds", query = "select b from BrandRequest b where b.brandRqstUid IN (:brandRqstUids) order by b.brandRqstUid desc"),
		//BLWBBCBSAUPGD-165 ( to reterive renewal history for requestID)
		@NamedQuery(name = "BrandRequest.findRenewalHistoryByRequestId", query = "select b from BrandRequest b where  b.intlParentBrandRqstUid=:intlParentBrandRqstUid and b.brandRqstUid <> :brandRqstUid or b.brandRqstUid =:intlBrandRqstUid order by b.brandRqstUid desc")

})
public class BrandRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BRAND_RQST_UID")
	private Long brandRqstUid;

	@Column(name = "BRAND_USAGE_DESC")
	private String brandUsageDesc;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_TS")
	private Date createTs;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CRNT_RQST_STS_UID")
	private int crntRqstStsUid;

	@Column(name = "INQ_RQST_IND")
	private byte inqRqstInd;

	@Column(name = "RQST_INQ_TYP_UID")
	private int rqstInqTypUid;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_TS")
	private Date updateTs;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "status")
	private int status;
	
	@Column(name = "COBRAND_REVIEW_FLOW")
	private Integer cobrandReviewFlow;

	@Column(name = "statusByUserId")
	private Long statusByUserId;
	
	@Column(name = "SUBMTR_PLN_NM")
	private String submitterPlanName;
	
	@Column(name = "SUBMITTER_EMAIL_ID")
	private String emailId;


	@Column(name = "statusByUserName")
	private String statusByUserName;
	
	public Integer getCobrandReviewFlow() {
		return cobrandReviewFlow;
	}

	public void setCobrandReviewFlow(Integer cobrandReviewFlow) {
		this.cobrandReviewFlow = cobrandReviewFlow;
	}


	@Temporal(TemporalType.DATE)
	@Column(name = "statusDate")
	private Date statusDate;
	
	@Column(name = "BEPC_MEET_IND")
	private byte nextBepcMeeting;
	
	@Column(name = "PLAN_MEET_IND")
	private byte nextPlanMeeting;
	
	@Column(name = "FLAG_IND_REVW")
	private byte flagIndependentReview;
	
	@Column(name = "GENERAL_COMMENTS")
	private String generalComments;
	
	@Column(name = "SUMMARY_TXT")
	private String summaryTxt;
	
	@Column(name = "BLUE_WEB_COMMENTS")
	private String blueWebComments;

	@Temporal(TemporalType.DATE)
	@Column(name = "REQTD_RESP_DATE")
	private Date requestedResponseDate;
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_APPROVED_DT")
	private Date cbApprovedDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_RENEWAL_DT")
	private Date cbRenewalDate;
	
	@Column(name="CB_RENEWAL_FLG", length=1)
	private String cbRenewalFlag;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_ACTUAL_RENEWAL_DT")
	private Date cbActualRenewalDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_EXPIRY_DT")
	private Date cbExpiryDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_SAMPLE_UPLOAD_DUE_DT")
	private Date cbSampleUploadDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CB_SAMPLE_UPLOAD_ACTUAL_DT")
	private Date cbSampleUploadActualDate;

	@Column(name="CB_STRATEGIC_RENEW_RATIONAL", length=2000)
	private String cbStrategicRenewRational;
	
	@Column(name="CB_STRATEGIC_DECISION_FACT", length=2000)
	private String cbStrategicDecisionFact;
	
	@Column(name = "PARENT_BRAND_RQST_UID")
	private Long parentBrandRqstUid;
	
	//BLWBBCBSAUPGD-143 changes begin
	@Temporal(TemporalType.DATE)
	@Column(name = "GBR_DERIVATIVE_APPROVAL_DT")
	private Date gbrDerivativeApprovalDate;
	
	@Column(name = "GBR_SEND_REMAINDER")
	private byte gbrSendRemainder;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "GBR_DERIVATIVE_REMAINDER_DT")
	private Date gbrDerivativeRemainderDate;
	//BLWBBCBSAUPGD-143 changes end
	
	//BLWBBCBSAUPGD-165 changes begin
	@Column(name = "INTL_PARENT_BRAND_RQST_UID")
	private Long intlParentBrandRqstUid;
	//BLWBBCBSAUPGD-165 changes end
	
	//ServiceCategory Questions enhancement start
	@Column(name = "SRVC_BLUE_BENEFITS")
	private String serviceCategoryBlueBenefit;
		
	@Column(name = "SRVC_NATIONAL_ACCOUNT_MEMBERS")
	private String serviceCategoryNationalAccountMember;
		
	@Column(name = "SRVC_SERVICES_ENTAIL")
	private String serviceCategoryServiceEntail;
	
	@Column(name = "SRVC_FLAG")
	private String serviceCatQuestionsFlag;
	//ServiceCategory Questions enhancement end
	
	//Cobranding Criteria Requirement customisation start

	@Column(name="DEMO_FINANCIAL")
	private String demoFinancial;

	@Column(name="NO_FELONY_RECORD")
	private String noFelonyRecord;

	@Column(name="REPUTATION_BRANDS")
	private String reputationBrand;

	@Column(name="PROHIBITED_CPMNY")
	private String prohibitatedCompany;
	
	@Column(name="NO_MISUSE_OF_BRANDS")
	private String noMisuseOfBrands;
	
	//Cobranding Criteria Requirement customisation end

	//Co-Branding Partner Form 17-question enhancement start
	@Column(name = "CB_Q1_LEGAL_NAME_CNFRMD")
	private String cbQ1LegalNameCnfrmd;

	@Column(name = "CB_Q2_DEBIT_CARD_IND")
	private String cbQ2DebitCardInd;

	@Column(name = "CB_Q2_LICENSE_AGMT_DT")
	private String cbQ2LicenseAgmtDt;

	@Column(name = "CB_Q3_CLIENT_LIST_IND")
	private String cbQ3ClientListInd;

	@Column(name = "CB_Q3_EXCEPTION_ACK_IND")
	private String cbQ3ExceptionAckInd;

	@Column(name = "CB_Q4_BRAND_MISUSE_IND")
	private String cbQ4BrandMisuseInd;

	@Column(name = "CB_Q4_MISUSE_LINKS_TXT")
	private String cbQ4MisuseLinksTxt;

	@Column(name = "CB_Q4_MISUSE_CONTACT_TXT")
	private String cbQ4MisuseContactTxt;

	@Column(name = "CB_Q4_MISUSE_ACK_IND")
	private String cbQ4MisuseAckInd;

	@Column(name = "CB_Q5_NAME_LOGO_INFRNG_IND")
	private String cbQ5NameLogoInfrngInd;

	@Column(name = "CB_Q5_INFRNG_LINKS_TXT")
	private String cbQ5InfrngLinksTxt;

	@Column(name = "CB_Q5_INFRNG_CONTACT_TXT")
	private String cbQ5InfrngContactTxt;

	@Column(name = "CB_Q5_INFRNG_ACK_IND")
	private String cbQ5InfrngAckInd;

	@Column(name = "CB_Q6_FINL_STABLE_IND")
	private String cbQ6FinlStableInd;

	@Column(name = "CB_Q7_FELONY_IND")
	private String cbQ7FelonyInd;

	@Column(name = "CB_Q8_NOT_ON_LIST_IND")
	private String cbQ8NotOnListInd;

	@Column(name = "CB_Q9_REPUTATION_IND")
	private String cbQ9ReputationInd;

	@Column(name = "CB_Q10_INTER_PLAN_EXEC_TXT")
	private String cbQ10InterPlanExecTxt;

	@Column(name = "CB_Q11_OTHER_TXT")
	private String cbQ11OtherTxt;

	@Column(name = "CB_Q12_TELEHEALTH_SVC_IND")
	private String cbQ12TelehealthSvcInd;

	@Column(name = "CB_Q13_VIRTUAL_ONLY_IND")
	private String cbQ13VirtualOnlyInd;

	@Column(name = "CB_Q16_PROVIDER_OUTREACH_IND")
	private String cbQ16ProviderOutreachInd;

	@Column(name = "CB_Q17_PROVIDER_OUTREACH_TXT")
	private String cbQ17ProviderOutreachTxt;
	//Co-Branding Partner Form 17-question enhancement end
	
	public String getServiceCatQuestionsFlag() {
		return serviceCatQuestionsFlag;
	}

	public void setServiceCatQuestionsFlag(String serviceCatQuestionsFlag) {
		this.serviceCatQuestionsFlag = serviceCatQuestionsFlag;
	}

	public String getServiceCategoryBlueBenefit() {
		return serviceCategoryBlueBenefit;
	}

	public void setServiceCategoryBlueBenefit(String serviceCategoryBlueBenefit) {
		this.serviceCategoryBlueBenefit = serviceCategoryBlueBenefit;
	}
	
	public String getServiceCategoryServiceEntail() {
		return serviceCategoryServiceEntail;
	}

	public void setServiceCategoryServiceEntail(String serviceCategoryServiceEntail) {
		this.serviceCategoryServiceEntail = serviceCategoryServiceEntail;
	}
	
	public String getServiceCategoryNationalAccountMember() {
		return serviceCategoryNationalAccountMember;
	}

	public void setServiceCategoryNationalAccountMember(String serviceCategoryNationalAccountMember) {
		this.serviceCategoryNationalAccountMember = serviceCategoryNationalAccountMember;
	}
	
	//ServiceCategory Questions enhancement end
	public Long getParentBrandRqstUid() {
		return parentBrandRqstUid;
	}

	public void setParentBrandRqstUid(Long parentBrandRqstUid) {
		this.parentBrandRqstUid = parentBrandRqstUid;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	/*public Long getEmailId() {
		return emailId;
	}

	public void setEmailId(Long emailId) {
		this.emailId = emailId;
	}
*/
	private transient String[] bcbaSupportList;
	
	//private transient CobrandRenewalType cobrandRenewalType;
	/*public int getCobrandReviewFlow() {
		return cobrandReviewFlow;
	}

	public void setCobrandReviewFlow(int cobrandReviewFlow) {
		this.cobrandReviewFlow = cobrandReviewFlow;
	}

	*/

	public String[] getBcbaSupportList() {
		return bcbaSupportList;
	}

	public void setBcbaSupportList(String[] bcbaSupportList) {
		this.bcbaSupportList = bcbaSupportList;
	}

	public Date getCbApprovedDate() {
		return cbApprovedDate;
	}

	public void setCbApprovedDate(Date cbApprovedDate) {
		this.cbApprovedDate = cbApprovedDate;
	}

	public Date getCbRenewalDate() {
		return cbRenewalDate;
	}

	public void setCbRenewalDate(Date cbRenewalDate) {
		this.cbRenewalDate = cbRenewalDate;
	}

	public String getCbRenewalFlag() {
		return cbRenewalFlag;
	}

	public void setCbRenewalFlag(String cbRenewalFlag) {
		this.cbRenewalFlag = cbRenewalFlag;
	}

	public Date getCbActualRenewalDate() {
		return cbActualRenewalDate;
	}

	public void setCbActualRenewalDate(Date cbActualRenewalDate) {
		this.cbActualRenewalDate = cbActualRenewalDate;
	}

	public Date getCbExpiryDate() {
		return cbExpiryDate;
	}

	public void setCbExpiryDate(Date cbExpiryDate) {
		this.cbExpiryDate = cbExpiryDate;
	}

	public Date getCbSampleUploadDate() {
		return cbSampleUploadDate;
	}

	public void setCbSampleUploadDate(Date cbSampleUploadDate) {
		this.cbSampleUploadDate = cbSampleUploadDate;
	}

	public Date getCbSampleUploadActualDate() {
		return cbSampleUploadActualDate;
	}

	public void setCbSampleUploadActualDate(Date cbSampleUploadActualDate) {
		this.cbSampleUploadActualDate = cbSampleUploadActualDate;
	}

	public String getCbStrategicRenewRational() {
		return cbStrategicRenewRational;
	}

	public void setCbStrategicRenewRational(String cbStrategicRenewRational) {
		this.cbStrategicRenewRational = cbStrategicRenewRational;
	}

	public String getCbStrategicDecisionFact() {
		return cbStrategicDecisionFact;
	}

	public void setCbStrategicDecisionFact(String cbStrategicDecisionFact) {
		this.cbStrategicDecisionFact = cbStrategicDecisionFact;
	}

	// uni-directional many-to-one association to CobrandReviewType
	@ManyToOne
	@JoinColumn(name = "COBRAND_REVW_TYP_UID")
	private CobrandReviewType cobrandReviewType;
	
	
	
	@ManyToOne
	/*@JoinColumn(name = "BRAND_RQST_UID", insertable = false, updatable = false)*/
	@JoinColumns({
		    @JoinColumn(name = "ACTVTY_START_TS", referencedColumnName = "ACTVTY_START_TS", insertable = false, updatable = false),
			@JoinColumn(name = "BRAND_RQST_UID", referencedColumnName = "BRAND_RQST_UID", insertable = false, updatable = false)})
	private RequestActivity requestActivity;
	
	@ManyToOne
	@JoinColumn(name = "COBRAND_RENW_TYP_UID")
	private CobrandReviewType cobrandRenewalType;

	// uni-directional many-to-one association to LegalEntity
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "LEGAL_ENTITY_UID", insertable = true, updatable = true)
	private LegalEntity legalEntity;

	// uni-directional many-to-one association to LegalEntity
	@ManyToOne
	@JoinColumn(name = "PRTNR_LEGAL_ENTITY_UID")
	private LegalEntity partnerLegalEntity;

	@ManyToOne
	@JoinColumn(name = "ASCTD_LEGAL_ENTITY_UID")
	private LegalEntity assocLegalEntity;

	@ManyToOne
	@JoinColumn(name = "LEGAL_ENTITY_RELSHP_CD")
	private LegalEntityRelationship legalEntityRelationship;

	// uni-directional many-to-one association to LegalEntityAssociation
	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "LEGAL_ENTITY_UID", referencedColumnName = "LEGAL_ENTITY_UID", insertable = false, updatable = false),
			@JoinColumn(name = "ASCTD_LEGAL_ENTITY_UID", referencedColumnName = "ASCTD_LEGAL_ENTITY_UID", insertable = false, updatable = false),
			@JoinColumn(name = "LEGAL_ENTITY_RELSHP_CD", referencedColumnName = "LEGAL_ENTITY_RELSHP_CD", insertable = false, updatable = false) })
	@Fetch(FetchMode.JOIN)
	private LegalEntityAssociation legalEntityAssociation;

	// uni-directional many-to-one association to RequestCategory
	@ManyToOne
	@JoinColumn(name = "RQST_CTGY_UID")
	private RequestCategory requestCategory;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "brandRequest")
	@Fetch(FetchMode.JOIN)
	private Set<BrandRequestServiceCategory> brandRequestServiceCategories;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "brandRequest", cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	private Set<UserUploadFile> userUploadFiles;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "brandRequest", cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	private Set<UserUploadCobrandSample> UserUploadCobrandSample;

	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "brandRequest", cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	private List<BrandRequestBcbsaSupport> brandRequestBcbsaSupport;
	

	

	public BrandRequest() {
	}

	public Long getBrandRqstUid() {
		return this.brandRqstUid;
	}

	public void setBrandRqstUid(Long brandRqstUid) {
		this.brandRqstUid = brandRqstUid;
	}

	public String getBrandUsageDesc() {
		return this.brandUsageDesc;
	}

	public void setBrandUsageDesc(String brandUsageDesc) {
		this.brandUsageDesc = brandUsageDesc;
	}

	public Date getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getCrntRqstStsUid() {
		return this.crntRqstStsUid;
	}

	public void setCrntRqstStsUid(int crntRqstStsUid) {
		this.crntRqstStsUid = crntRqstStsUid;
	}

	public byte getInqRqstInd() {
		return this.inqRqstInd;
	}

	public void setInqRqstInd(byte inqRqstInd) {
		this.inqRqstInd = inqRqstInd;
	}

	public int getRqstInqTypUid() {
		return this.rqstInqTypUid;
	}

	public void setRqstInqTypUid(int rqstInqTypUid) {
		this.rqstInqTypUid = rqstInqTypUid;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public CobrandReviewType getCobrandReviewType() {
		return this.cobrandReviewType;
	}

	public void setCobrandReviewType(CobrandReviewType cobrandReviewType) {
		this.cobrandReviewType = cobrandReviewType;
	}

	public LegalEntity getLegalEntity() {
		return this.legalEntity;
	}

	public void setLegalEntity(LegalEntity legalEntity) {
		this.legalEntity = legalEntity;
	}

	public LegalEntity getPartnerLegalEntity() {
		return this.partnerLegalEntity;
	}

	public void setPartnerLegalEntity(LegalEntity partnerLegalEntity) {
		this.partnerLegalEntity = partnerLegalEntity;
	}

	public LegalEntityAssociation getLegalEntityAssociation() {
		return this.legalEntityAssociation;
	}

	public void setLegalEntityAssociation(LegalEntityAssociation legalEntityAssociation) {
		this.legalEntityAssociation = legalEntityAssociation;
	}

	public RequestCategory getRequestCategory() {
		return this.requestCategory;
	}

	public LegalEntityRelationship getLegalEntityRelationship() {
		return legalEntityRelationship;
	}

	public void setLegalEntityRelationship(LegalEntityRelationship legalEntityRelationship) {
		this.legalEntityRelationship = legalEntityRelationship;
	}

	public void setRequestCategory(RequestCategory requestCategory) {
		this.requestCategory = requestCategory;
	}

	public Set<BrandRequestServiceCategory> getBrandRequestServiceCategories() {
		return brandRequestServiceCategories;
	}

	public void setBrandRequestServiceCategories(Set<BrandRequestServiceCategory> brandRequestServiceCategories) {
		this.brandRequestServiceCategories = brandRequestServiceCategories;
	}

	public Set<UserUploadFile> getUserUploadFiles() {
		return userUploadFiles;
	}

	public void setUserUploadFiles(Set<UserUploadFile> userUploadFiles) {
		this.userUploadFiles = userUploadFiles;
	}
	
	public Set<UserUploadCobrandSample> getUserUploadCobrandSample() {
		return UserUploadCobrandSample;
	}

	public void setUserUploadCobrandSample(Set<UserUploadCobrandSample> userUploadCobrandSample) {
		UserUploadCobrandSample = userUploadCobrandSample;
	}
	

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Long getStatusByUserId() {
		return statusByUserId;
	}

	public void setStatusByUserId(Long statusByUserId) {
		this.statusByUserId = statusByUserId;
	}

	public String getStatusByUserName() {
		return statusByUserName;
	}

	public void setStatusByUserName(String statusByUserName) {
		this.statusByUserName = statusByUserName;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public LegalEntity getAssocLegalEntity() {
		return assocLegalEntity;
	}

	public void setAssocLegalEntity(LegalEntity assocLegalEntity) {
		this.assocLegalEntity = assocLegalEntity;
	}

	public String getSubmitterPlanName() {
		return submitterPlanName;
	}

	public void setSubmitterPlanName(String submitterPlanName) {
		this.submitterPlanName = submitterPlanName;
	}

	public byte getNextBepcMeeting() {
		return nextBepcMeeting;
	}

	public void setNextBepcMeeting(byte nextBepcMeeting) {
		this.nextBepcMeeting = nextBepcMeeting;
	}

	public byte getNextPlanMeeting() {
		return nextPlanMeeting;
	}

	public void setNextPlanMeeting(byte nextPlanMeeting) {
		this.nextPlanMeeting = nextPlanMeeting;
	}

	public byte getFlagIndependentReview() {
		return flagIndependentReview;
	}

	public void setFlagIndependentReview(byte flagIndependentReview) {
		this.flagIndependentReview = flagIndependentReview;
	}

	public String getGeneralComments() {
		return generalComments;
	}

	public void setGeneralComments(String generalComments) {
		this.generalComments = generalComments;
	}

	public String getSummaryTxt() {
		return summaryTxt;
	}

	public void setSummaryTxt(String summaryTxt) {
		this.summaryTxt = summaryTxt;
	}

	public String getBlueWebComments() {
		return blueWebComments;
	}

	public void setBlueWebComments(String blueWebComments) {
		this.blueWebComments = blueWebComments;
	}

	public Date getRequestedResponseDate() {
		return requestedResponseDate;
	}

	public void setRequestedResponseDate(Date requestedResponseDate) {
		this.requestedResponseDate = requestedResponseDate;
	}
	public List<BrandRequestBcbsaSupport> getBrandRequestBcbsaSupport() {
		return brandRequestBcbsaSupport;
	}

	public void setBrandRequestBcbsaSupport(List<BrandRequestBcbsaSupport> brandRequestBcbsaSupport) {
		this.brandRequestBcbsaSupport = brandRequestBcbsaSupport;
	}
	
	public CobrandReviewType getCobrandRenewalType() {
		return cobrandRenewalType;
	}

	public void setCobrandRenewalType(CobrandReviewType cobrandRenewalType) {
		this.cobrandRenewalType = cobrandRenewalType;
	}
	//BLWBBCBSAUPGD-143 changes begin

	public Date getGbrDerivativeApprovalDate() {
		return gbrDerivativeApprovalDate;
	}

	public void setGbrDerivativeApprovalDate(Date gbrDerivativeApprovalDate) {
		this.gbrDerivativeApprovalDate = gbrDerivativeApprovalDate;
	}

	public byte getGbrSendRemainder() {
		return gbrSendRemainder;
	}

	public void setGbrSendRemainder(byte gbrSendRemainder) {
		this.gbrSendRemainder = gbrSendRemainder;
	}

	public Date getGbrDerivativeRemainderDate() {
		return gbrDerivativeRemainderDate;
	}

	public void setGbrDerivativeRemainderDate(Date gbrDerivativeRemainderDate) {
		this.gbrDerivativeRemainderDate = gbrDerivativeRemainderDate;
	}
	//BLWBBCBSAUPGD-165 changes begin
	public Long getIntlParentBrandRqstUid() {
		return intlParentBrandRqstUid;
	}

	public void setIntlParentBrandRqstUid(Long intlParentBrandRqstUid) {
		this.intlParentBrandRqstUid = intlParentBrandRqstUid;
	}

	public String getDemoFinancial() {
		return demoFinancial;
	}

	public void setDemoFinancial(String demoFinancial) {
		this.demoFinancial = demoFinancial;
	}

	public String getNoFelonyRecord() {
		return noFelonyRecord;
	}

	public void setNoFelonyRecord(String noFelonyRecord) {
		this.noFelonyRecord = noFelonyRecord;
	}

	public String getReputationBrand() {
		return reputationBrand;
	}

	public void setReputationBrand(String reputationBrand) {
		this.reputationBrand = reputationBrand;
	}

	public String getProhibitatedCompany() {
		return prohibitatedCompany;
	}

	public void setProhibitatedCompany(String prohibitatedCompany) {
		this.prohibitatedCompany = prohibitatedCompany;
	}

	public String getNoMisuseOfBrands() {
		return noMisuseOfBrands;
	}

	public void setNoMisuseOfBrands(String noMisuseOfBrands) {
		this.noMisuseOfBrands = noMisuseOfBrands;
	}
	
	
	//BLWBBCBSAUPGD-165 changes end
	//BLWBBCBSAUPGD-143 changes end
	
	
	
	

	//Co-Branding Partner Form 17-question getters/setters start

	public String getCbQ1LegalNameCnfrmd() { return cbQ1LegalNameCnfrmd; }
	public void setCbQ1LegalNameCnfrmd(String v) { this.cbQ1LegalNameCnfrmd = v; }

	public String getCbQ2DebitCardInd() { return cbQ2DebitCardInd; }
	public void setCbQ2DebitCardInd(String v) { this.cbQ2DebitCardInd = v; }

	public String getCbQ2LicenseAgmtDt() { return cbQ2LicenseAgmtDt; }
	public void setCbQ2LicenseAgmtDt(String v) { this.cbQ2LicenseAgmtDt = v; }

	public String getCbQ3ClientListInd() { return cbQ3ClientListInd; }
	public void setCbQ3ClientListInd(String v) { this.cbQ3ClientListInd = v; }

	public String getCbQ3ExceptionAckInd() { return cbQ3ExceptionAckInd; }
	public void setCbQ3ExceptionAckInd(String v) { this.cbQ3ExceptionAckInd = v; }

	public String getCbQ4BrandMisuseInd() { return cbQ4BrandMisuseInd; }
	public void setCbQ4BrandMisuseInd(String v) { this.cbQ4BrandMisuseInd = v; }

	public String getCbQ4MisuseLinksTxt() { return cbQ4MisuseLinksTxt; }
	public void setCbQ4MisuseLinksTxt(String v) { this.cbQ4MisuseLinksTxt = v; }

	public String getCbQ4MisuseContactTxt() { return cbQ4MisuseContactTxt; }
	public void setCbQ4MisuseContactTxt(String v) { this.cbQ4MisuseContactTxt = v; }

	public String getCbQ4MisuseAckInd() { return cbQ4MisuseAckInd; }
	public void setCbQ4MisuseAckInd(String v) { this.cbQ4MisuseAckInd = v; }

	public String getCbQ5NameLogoInfrngInd() { return cbQ5NameLogoInfrngInd; }
	public void setCbQ5NameLogoInfrngInd(String v) { this.cbQ5NameLogoInfrngInd = v; }

	public String getCbQ5InfrngLinksTxt() { return cbQ5InfrngLinksTxt; }
	public void setCbQ5InfrngLinksTxt(String v) { this.cbQ5InfrngLinksTxt = v; }

	public String getCbQ5InfrngContactTxt() { return cbQ5InfrngContactTxt; }
	public void setCbQ5InfrngContactTxt(String v) { this.cbQ5InfrngContactTxt = v; }

	public String getCbQ5InfrngAckInd() { return cbQ5InfrngAckInd; }
	public void setCbQ5InfrngAckInd(String v) { this.cbQ5InfrngAckInd = v; }

	public String getCbQ6FinlStableInd() { return cbQ6FinlStableInd; }
	public void setCbQ6FinlStableInd(String v) { this.cbQ6FinlStableInd = v; }

	public String getCbQ7FelonyInd() { return cbQ7FelonyInd; }
	public void setCbQ7FelonyInd(String v) { this.cbQ7FelonyInd = v; }

	public String getCbQ8NotOnListInd() { return cbQ8NotOnListInd; }
	public void setCbQ8NotOnListInd(String v) { this.cbQ8NotOnListInd = v; }

	public String getCbQ9ReputationInd() { return cbQ9ReputationInd; }
	public void setCbQ9ReputationInd(String v) { this.cbQ9ReputationInd = v; }

	public String getCbQ10InterPlanExecTxt() { return cbQ10InterPlanExecTxt; }
	public void setCbQ10InterPlanExecTxt(String v) { this.cbQ10InterPlanExecTxt = v; }

	public String getCbQ11OtherTxt() { return cbQ11OtherTxt; }
	public void setCbQ11OtherTxt(String v) { this.cbQ11OtherTxt = v; }

	public String getCbQ12TelehealthSvcInd() { return cbQ12TelehealthSvcInd; }
	public void setCbQ12TelehealthSvcInd(String v) { this.cbQ12TelehealthSvcInd = v; }

	public String getCbQ13VirtualOnlyInd() { return cbQ13VirtualOnlyInd; }
	public void setCbQ13VirtualOnlyInd(String v) { this.cbQ13VirtualOnlyInd = v; }

	public String getCbQ16ProviderOutreachInd() { return cbQ16ProviderOutreachInd; }
	public void setCbQ16ProviderOutreachInd(String v) { this.cbQ16ProviderOutreachInd = v; }

	public String getCbQ17ProviderOutreachTxt() { return cbQ17ProviderOutreachTxt; }
	public void setCbQ17ProviderOutreachTxt(String v) { this.cbQ17ProviderOutreachTxt = v; }

	//Co-Branding Partner Form 17-question getters/setters end

}
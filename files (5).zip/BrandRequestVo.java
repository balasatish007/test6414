package com.bcbsa.brp.vo;

import com.bcbsa.brp.model.BrandRequestBcbsaSupport;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class BrandRequestVo implements Serializable {

	private static final long serialVersionUID = 4370693338138234503L;

	private Long brandRqstUid;
	private String legalName;
	private String legalNameUid;
	private String[] tradeNames;
	private CobrandReviewTypeVo cobrandReviewType;
	private CobrandRenewalType cobrandRenewalType;
	private String[] coBrandBcbsaSupportList;
	private List<BrandRequestBcbsaSupport> brandRequestBcbsaSupport;
	private List<ServiceCategoryVo> brandRqstServiceCategories;
	
	private String brandRqstServiceCategoriesCsv = "";
	private String othSrvcCtgyNm;
	private UsStateVo stateOfIncorporation;
	private String address1;
	private String address2;
	private String city;
	private UsStateVo state;
	private String zipCode;
	private String phone;
	private String dandbNumber;
	private String companyWebSite;
	private String isUnlicensed;
	private BusinessTypeVo businessType;
	private GroupAccountTypeVo groupAccountType;
	private PlanVo plan;
	private String isTpa;
	private String coBrandDescription;
	private List<FileAttachmentVo> attachmentList;
	private String createTs;
	private String updateTs;
	private String updatedBy;
	private String createdBy;
	private String portalUser;// The liferay user
	private String customUserName;
	private String customFullName;
	private int status;
	private String submitterPlanName;
	private byte nextBepcMeeting;
	private byte nextPlanMeeting;
	private byte flagIndependentReview;
	private String generalComments;
	private String summaryTxt;
	private String blueWebComments;
	private String requestedResponseDate;
	private String cbStrategicRenewRational;
    private String cbStrategicDecisionFact;
    private Long emailId;
	private String coBrandFileDescription;
	private String cbApprovedDate;
	private String cbRenewalDate;
	private String cbSampleUploadDate;
	private String cbSampleUploadActualDate;
	private String submitterEmail;
	private Date gbrDerivativeApprovalDate;
	private byte gbrSendRemainder;
	private Date gbrDerivativeRemainderDate;
	//BLWBBCBSAUPGD-165 changes begin
	private Long parentBrandRqstUid;
	private Long intlParentBrandRqstUid;
	private boolean maxRecord;
	//BLWBBCBSAUPGD-165 changes end
	private String  updatedByOriginal;
	
	//Cobranding Criteria Requirement customisation start
	//commenting for future release start
	private String demoFinancial;
	private String noFelonyRecord;
	private String reputationBrand;
	private String prohibitatedCompany;
	private String noMisuseOfBrands;
	//commenting for future release end
	//Cobranding Criteria Requirement customisation end

	//Co-Branding Partner Form 17-question enhancement start
	private String cbQ1LegalNameCnfrmd;
	private String cbQ2DebitCardInd;
	private String cbQ2LicenseAgmtDt;
	private String cbQ3ClientListInd;
	private String cbQ3ExceptionAckInd;
	private String cbQ4BrandMisuseInd;
	private String cbQ4MisuseLinksTxt;
	private String cbQ4MisuseContactTxt;
	private String cbQ4MisuseAckInd;
	private String cbQ5NameLogoInfrngInd;
	private String cbQ5InfrngLinksTxt;
	private String cbQ5InfrngContactTxt;
	private String cbQ5InfrngAckInd;
	private String cbQ6FinlStableInd;
	private String cbQ7FelonyInd;
	private String cbQ8NotOnListInd;
	private String cbQ9ReputationInd;
	private String cbQ10InterPlanExecTxt;
	private String cbQ11OtherTxt;
	private String cbQ12TelehealthSvcInd;
	private String cbQ13VirtualOnlyInd;
	private String cbQ16ProviderOutreachInd;
	private String cbQ17ProviderOutreachTxt;
	//Co-Branding Partner Form 17-question enhancement end
	
	//Service Category Questions customisation start
	private String serviceCategoryBlueBenefit;
	private String serviceCategoryNationalAccountMember;
	private String serviceCategoryServiceEntail;
	private String serviceCatQuestionsFlag;
	private boolean enableServiceCategoryQuestions;
	
	//commenting for future release start
	public String getDemoFinancial() {
		return demoFinancial;
	}

	public void setDemoFinancial(String demoFinancial) {
		this.demoFinancial = demoFinancial;
	}

	public String getNoFelonyRecord() {
		return noFelonyRecord;
	}

	public void setNoFelonyRecord(String noFelonyRecord) {
		this.noFelonyRecord = noFelonyRecord;
	}

	public String getReputationBrand() {
		return reputationBrand;
	}

	public void setReputationBrand(String reputationBrand) {
		this.reputationBrand = reputationBrand;
	}

	public String getProhibitatedCompany() {
		return prohibitatedCompany;
	}

	public void setProhibitatedCompany(String prohibitatedCompany) {
		this.prohibitatedCompany = prohibitatedCompany;
	}
	
	public String getNoMisuseOfBrands() {
		return noMisuseOfBrands;
	}

	public void setNoMisuseOfBrands(String noMisuseOfBrands) {
		this.noMisuseOfBrands = noMisuseOfBrands;
	}

	//commenting for future release end

	
	public String getServiceCatQuestionsFlag() {
		return serviceCatQuestionsFlag;
	}

	public void setServiceCatQuestionsFlag(String serviceCatQuestionsFlag) {
		this.serviceCatQuestionsFlag = serviceCatQuestionsFlag;
	}

	public String getServiceCategoryBlueBenefit() {
		return serviceCategoryBlueBenefit;
	}

	public void setServiceCategoryBlueBenefit(String serviceCategoryBlueBenefit) {
		this.serviceCategoryBlueBenefit = serviceCategoryBlueBenefit;
	}

	public String getServiceCategoryNationalAccountMember() {
		return serviceCategoryNationalAccountMember;
	}

	public void setServiceCategoryNationalAccountMember(String serviceCategoryNationalAccountMember) {
		this.serviceCategoryNationalAccountMember = serviceCategoryNationalAccountMember;
	}

	public String getServiceCategoryServiceEntail() {
		return serviceCategoryServiceEntail;
	}

	public void setServiceCategoryServiceEntail(String serviceCategoryServiceEntail) {
		this.serviceCategoryServiceEntail = serviceCategoryServiceEntail;
	}
	
	public boolean isEnableServiceCategoryQuestions() {
		if(serviceCategoryBlueBenefit!=null &&serviceCategoryNationalAccountMember!=null && serviceCategoryServiceEntail!=null) {
			enableServiceCategoryQuestions=true;
		}
		return enableServiceCategoryQuestions;
	}

	public void setEnableServiceCategoryQuestions(boolean enableServiceCategoryQuestions) {
		this.enableServiceCategoryQuestions = enableServiceCategoryQuestions;
	}
	
	//Service Category Questions customisation end
	public String getSubmitterEmail() {
		return submitterEmail;
	}

	public void setSubmitterEmail(String submitterEmail) {
		this.submitterEmail = submitterEmail;
	}

	public Long getEmailId() {
		return emailId;
	}

	public void setEmailId(Long emailId) {
		this.emailId = emailId;
	}

	public String getCbSampleUploadDate() {
		return cbSampleUploadDate;
	}

	public void setCbSampleUploadDate(String cbSampleUploadDate) {
		this.cbSampleUploadDate = cbSampleUploadDate;
	}

	public String getCbSampleUploadActualDate() {
		return cbSampleUploadActualDate;
	}

	public void setCbSampleUploadActualDate(String cbSampleUploadActualDate) {
		this.cbSampleUploadActualDate = cbSampleUploadActualDate;
	}

	public String getCbApprovedDate() {
		return cbApprovedDate;
	}

	public void setCbApprovedDate(String cbApprovedDate) {
		this.cbApprovedDate = cbApprovedDate;
	}

	public String getCbRenewalDate() {
		return cbRenewalDate;
	}

	public void setCbRenewalDate(String cbRenewalDate) {
		this.cbRenewalDate = cbRenewalDate;
	}

	public String getCbStrategicDecisionFact() {
		return cbStrategicDecisionFact;
	}

	public void setCbStrategicDecisionFact(String cbStrategicDecisionFact) {
		this.cbStrategicDecisionFact = cbStrategicDecisionFact;
	}
	
	public String getCoBrandFileDescription() {
		return coBrandFileDescription;
	}

	public void setCoBrandFileDescription(String coBrandFileDescription) {
		this.coBrandFileDescription = coBrandFileDescription;
	}

	public Long getBrandRqstUid() {
		return brandRqstUid;
	}

	public void setBrandRqstUid(Long brandRqstUid) {
		this.brandRqstUid = brandRqstUid;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String[] getTradeNames() {
		return tradeNames;
	}

	public void setTradeNames(String[] tradeNames) {
		this.tradeNames = tradeNames;
	}

	public CobrandReviewTypeVo getCobrandReviewType() {
		if (cobrandReviewType == null) {
			cobrandReviewType = new CobrandReviewTypeVo();
		}
		return cobrandReviewType;
	}

	public void setCobrandReviewType(CobrandReviewTypeVo cobrandReviewType) {
		this.cobrandReviewType = cobrandReviewType;
	}

	public List<ServiceCategoryVo> getBrandRqstServiceCategories() {
		return brandRqstServiceCategories;
	}

	public void setBrandRqstServiceCategories(List<ServiceCategoryVo> brandRqstServiceCategories) {
		this.brandRqstServiceCategories = brandRqstServiceCategories;
	}

	public String getBrandRqstServiceCategoriesCsv() {

		if (brandRqstServiceCategories != null && !brandRqstServiceCategories.isEmpty()) {
			for (ServiceCategoryVo scvo : brandRqstServiceCategories) {
				brandRqstServiceCategoriesCsv += "," + scvo.getSrvcCtgyUid() + ",";
			}
		}
		return brandRqstServiceCategoriesCsv + ",";
	}

	public void setBrandRqstServiceCategoriesCsv(String brandRqstServiceCategoriesCsv) {
		this.brandRqstServiceCategoriesCsv = brandRqstServiceCategoriesCsv;
	}

	public String getOthSrvcCtgyNm() {
		return othSrvcCtgyNm;
	}

	public void setOthSrvcCtgyNm(String othSrvcCtgyNm) {
		this.othSrvcCtgyNm = othSrvcCtgyNm;
	}

	public String getAddress1() {
		return address1;
	}

	public UsStateVo getStateOfIncorporation() {
		return stateOfIncorporation;
	}

	public void setStateOfIncorporation(UsStateVo stateOfIncorporation) {
		this.stateOfIncorporation = stateOfIncorporation;
	}

	public UsStateVo getState() {
		return state;
	}

	public void setState(UsStateVo state) {
		this.state = state;
	}

	public BusinessTypeVo getBusinessType() {
		return businessType;
	}

	public void setBusinessType(BusinessTypeVo businessType) {
		this.businessType = businessType;
	}

	public GroupAccountTypeVo getGroupAccountType() {
		return groupAccountType;
	}

	public void setGroupAccountType(GroupAccountTypeVo groupAccountType) {
		this.groupAccountType = groupAccountType;
	}

	public PlanVo getPlan() {
		return plan;
	}

	public void setPlan(PlanVo plan) {
		this.plan = plan;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDandbNumber() {
		return dandbNumber;
	}

	public void setDandbNumber(String dandbNumber) {
		this.dandbNumber = dandbNumber;
	}

	public String getCompanyWebSite() {
		return companyWebSite;
	}

	public void setCompanyWebSite(String companyWebSite) {
		this.companyWebSite = companyWebSite;
	}

	public String getIsUnlicensed() {
		return isUnlicensed;
	}

	public void setIsUnlicensed(String isUnlicensed) {
		this.isUnlicensed = isUnlicensed;
	}

	public String getIsTpa() {
		return isTpa;
	}

	public void setIsTpa(String isTpa) {
		this.isTpa = isTpa;
	}

	public String getCoBrandDescription() {
		return coBrandDescription;
	}

	public void setCoBrandDescription(String coBrandDescription) {
		this.coBrandDescription = coBrandDescription;
	}

	public String getPortalUser() {
		return portalUser;
	}

	public void setPortalUser(String portalUser) {
		this.portalUser = portalUser;
	}

	public List<FileAttachmentVo> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<FileAttachmentVo> attachmentList) {
		this.attachmentList = attachmentList;
	}

	public String getCreateTs() {
		return createTs;
	}

	public void setCreateTs(String createTs) {
		this.createTs = createTs;
	}

	public String getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCustomUserName() {
		return customUserName;
	}

	public void setCustomUserName(String customUserName) {
		this.customUserName = customUserName;
	}

	public String getCustomFullName() {
		return customFullName;
	}

	public void setCustomFullName(String customFullName) {
		this.customFullName = customFullName;
	}

	public String getLegalNameUid() {
		return legalNameUid;
	}

	public void setLegalNameUid(String legalNameUid) {
		this.legalNameUid = legalNameUid;
	}

	public String getSubmitterPlanName() {
		return submitterPlanName;
	}

	public void setSubmitterPlanName(String submitterPlanName) {
		this.submitterPlanName = submitterPlanName;
	}

	public byte getNextBepcMeeting() {
		return nextBepcMeeting;
	}

	public void setNextBepcMeeting(byte nextBepcMeeting) {
		this.nextBepcMeeting = nextBepcMeeting;
	}

	public byte getNextPlanMeeting() {
		return nextPlanMeeting;
	}

	public void setNextPlanMeeting(byte nextPlanMeeting) {
		this.nextPlanMeeting = nextPlanMeeting;
	}

	public byte getFlagIndependentReview() {
		return flagIndependentReview;
	}

	public void setFlagIndependentReview(byte flagIndependentReview) {
		this.flagIndependentReview = flagIndependentReview;
	}

	public String getGeneralComments() {
		return generalComments;
	}

	public void setGeneralComments(String generalComments) {
		this.generalComments = generalComments;
	}

	public String getSummaryTxt() {
		return summaryTxt;
	}

	public void setSummaryTxt(String summaryTxt) {
		this.summaryTxt = summaryTxt;
	}

	public String getBlueWebComments() {
		return blueWebComments;
	}

	public void setBlueWebComments(String blueWebComments) {
		this.blueWebComments = blueWebComments;
	}

	public String getRequestedResponseDate() {
		return requestedResponseDate;
	}

	public void setRequestedResponseDate(String requestedResponseDate) {
		this.requestedResponseDate = requestedResponseDate;
	}
	
	
	public CobrandRenewalType getCobrandRenewalType() {
		return cobrandRenewalType;
	}

	public void setCobrandRenewalType(CobrandRenewalType cobrandRenewalType) {
		this.cobrandRenewalType = cobrandRenewalType;
	}
	
	public String getCbStrategicRenewRational() {
		return cbStrategicRenewRational;
	}

	public void setCbStrategicRenewRational(String cbStrategicRenewRational) {
		this.cbStrategicRenewRational = cbStrategicRenewRational;
	}
	public String[] getCoBrandBcbsaSupportList() {
		return coBrandBcbsaSupportList;
	}

	public void setCoBrandBcbsaSupportList(String[] coBrandBcbsaSupportList) {
		this.coBrandBcbsaSupportList = coBrandBcbsaSupportList;
	}
	
	private List<CoBrandBcbsaSupportVO> selectedBcbaSupport;




	public List<CoBrandBcbsaSupportVO> getSelectedBcbaSupport() {
		return selectedBcbaSupport;
	}

	public void setSelectedBcbaSupport(List<CoBrandBcbsaSupportVO> selectedBcbaSupport) {
		this.selectedBcbaSupport = selectedBcbaSupport;
	}
	
	
	public List<BrandRequestBcbsaSupport> getBrandRequestBcbsaSupport() {
		return brandRequestBcbsaSupport;
	}

	public void setBrandRequestBcbsaSupport(List<BrandRequestBcbsaSupport> brandRequestBcbsaSupport) {
		this.brandRequestBcbsaSupport = brandRequestBcbsaSupport;
	}
	public Date getGbrDerivativeApprovalDate() {
		return gbrDerivativeApprovalDate;
	}
	public void setGbrDerivativeApprovalDate(Date gbrDerivativeApprovalDate) {
		this.gbrDerivativeApprovalDate = gbrDerivativeApprovalDate;
	}
	public byte getGbrSendRemainder() {
		return gbrSendRemainder;
	}
	public void setGbrSendRemainder(byte gbrSendRemainder) {
		this.gbrSendRemainder = gbrSendRemainder;
	}

	public Date getGbrDerivativeRemainderDate() {
		return gbrDerivativeRemainderDate;
	}

	public void setGbrDerivativeRemainderDate(Date gbrDerivativeRemainderDate) {
		this.gbrDerivativeRemainderDate = gbrDerivativeRemainderDate;
	}

	//BLWBBCBSAUPGD-165 changes begin
	public Long getParentBrandRqstUid() {
		return parentBrandRqstUid;
	}

	public void setParentBrandRqstUid(Long parentBrandRqstUid) {
		this.parentBrandRqstUid = parentBrandRqstUid;
	}

	public Long getIntlParentBrandRqstUid() {
		return intlParentBrandRqstUid;
	}

	public void setIntlParentBrandRqstUid(Long intlParentBrandRqstUid) {
		this.intlParentBrandRqstUid = intlParentBrandRqstUid;
	}

	public boolean isMaxRecord() {
		return maxRecord;
	}

	public void setMaxRecord(boolean maxRecord) {
		this.maxRecord = maxRecord;
	}

	public String getUpdatedByOriginal() {
		return updatedByOriginal;
	}

	public void setUpdatedByOriginal(String updatedByOriginal) {
		this.updatedByOriginal = updatedByOriginal;
	}
	
	//BLWBBCBSAUPGD-165 changes end
	
	//Co-Branding Partner Form 17-question getters/setters start

	public String getCbQ1LegalNameCnfrmd() { return cbQ1LegalNameCnfrmd; }
	public void setCbQ1LegalNameCnfrmd(String v) { this.cbQ1LegalNameCnfrmd = v; }
	public String getCbQ2DebitCardInd() { return cbQ2DebitCardInd; }
	public void setCbQ2DebitCardInd(String v) { this.cbQ2DebitCardInd = v; }
	public String getCbQ2LicenseAgmtDt() { return cbQ2LicenseAgmtDt; }
	public void setCbQ2LicenseAgmtDt(String v) { this.cbQ2LicenseAgmtDt = v; }
	public String getCbQ3ClientListInd() { return cbQ3ClientListInd; }
	public void setCbQ3ClientListInd(String v) { this.cbQ3ClientListInd = v; }
	public String getCbQ3ExceptionAckInd() { return cbQ3ExceptionAckInd; }
	public void setCbQ3ExceptionAckInd(String v) { this.cbQ3ExceptionAckInd = v; }
	public String getCbQ4BrandMisuseInd() { return cbQ4BrandMisuseInd; }
	public void setCbQ4BrandMisuseInd(String v) { this.cbQ4BrandMisuseInd = v; }
	public String getCbQ4MisuseLinksTxt() { return cbQ4MisuseLinksTxt; }
	public void setCbQ4MisuseLinksTxt(String v) { this.cbQ4MisuseLinksTxt = v; }
	public String getCbQ4MisuseContactTxt() { return cbQ4MisuseContactTxt; }
	public void setCbQ4MisuseContactTxt(String v) { this.cbQ4MisuseContactTxt = v; }
	public String getCbQ4MisuseAckInd() { return cbQ4MisuseAckInd; }
	public void setCbQ4MisuseAckInd(String v) { this.cbQ4MisuseAckInd = v; }
	public String getCbQ5NameLogoInfrngInd() { return cbQ5NameLogoInfrngInd; }
	public void setCbQ5NameLogoInfrngInd(String v) { this.cbQ5NameLogoInfrngInd = v; }
	public String getCbQ5InfrngLinksTxt() { return cbQ5InfrngLinksTxt; }
	public void setCbQ5InfrngLinksTxt(String v) { this.cbQ5InfrngLinksTxt = v; }
	public String getCbQ5InfrngContactTxt() { return cbQ5InfrngContactTxt; }
	public void setCbQ5InfrngContactTxt(String v) { this.cbQ5InfrngContactTxt = v; }
	public String getCbQ5InfrngAckInd() { return cbQ5InfrngAckInd; }
	public void setCbQ5InfrngAckInd(String v) { this.cbQ5InfrngAckInd = v; }
	public String getCbQ6FinlStableInd() { return cbQ6FinlStableInd; }
	public void setCbQ6FinlStableInd(String v) { this.cbQ6FinlStableInd = v; }
	public String getCbQ7FelonyInd() { return cbQ7FelonyInd; }
	public void setCbQ7FelonyInd(String v) { this.cbQ7FelonyInd = v; }
	public String getCbQ8NotOnListInd() { return cbQ8NotOnListInd; }
	public void setCbQ8NotOnListInd(String v) { this.cbQ8NotOnListInd = v; }
	public String getCbQ9ReputationInd() { return cbQ9ReputationInd; }
	public void setCbQ9ReputationInd(String v) { this.cbQ9ReputationInd = v; }
	public String getCbQ10InterPlanExecTxt() { return cbQ10InterPlanExecTxt; }
	public void setCbQ10InterPlanExecTxt(String v) { this.cbQ10InterPlanExecTxt = v; }
	public String getCbQ11OtherTxt() { return cbQ11OtherTxt; }
	public void setCbQ11OtherTxt(String v) { this.cbQ11OtherTxt = v; }
	public String getCbQ12TelehealthSvcInd() { return cbQ12TelehealthSvcInd; }
	public void setCbQ12TelehealthSvcInd(String v) { this.cbQ12TelehealthSvcInd = v; }
	public String getCbQ13VirtualOnlyInd() { return cbQ13VirtualOnlyInd; }
	public void setCbQ13VirtualOnlyInd(String v) { this.cbQ13VirtualOnlyInd = v; }
	public String getCbQ16ProviderOutreachInd() { return cbQ16ProviderOutreachInd; }
	public void setCbQ16ProviderOutreachInd(String v) { this.cbQ16ProviderOutreachInd = v; }
	public String getCbQ17ProviderOutreachTxt() { return cbQ17ProviderOutreachTxt; }
	public void setCbQ17ProviderOutreachTxt(String v) { this.cbQ17ProviderOutreachTxt = v; }

	//Co-Branding Partner Form 17-question getters/setters end

}